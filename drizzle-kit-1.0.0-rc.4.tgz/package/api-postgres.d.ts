import { a as ZodEffects, c as ZodObject, d as ZodTypeAny, f as ZodUndefined, h as objectOutputType, i as ZodDefault, l as ZodOptional, m as objectInputType, n as ZodArray, o as ZodLiteral, p as ZodUnion, r as ZodBoolean, s as ZodNumber, t as TypeOf, u as ZodString } from "./types-DQPabKbg.js";
import { PGlite } from "@electric-sql/pglite";
import { PgAsyncDatabase } from "drizzle-orm/pg-core/async";

//#region src/cli/validations/common.d.ts
declare const entitiesParams: {
  tablesFilter: ZodOptional<ZodUnion<[ZodString, ZodArray<ZodString, "many">]>>;
  schemaFilter: ZodOptional<ZodUnion<[ZodString, ZodArray<ZodString, "many">]>>;
  extensionsFilters: ZodOptional<ZodArray<ZodLiteral<"postgis">, "many">>;
  entities: ZodOptional<ZodObject<{
    roles: ZodDefault<ZodOptional<ZodUnion<[ZodBoolean, ZodObject<{
      provider: ZodOptional<ZodString>;
      include: ZodOptional<ZodArray<ZodString, "many">>;
      exclude: ZodOptional<ZodArray<ZodString, "many">>;
    }, "strip", ZodTypeAny, {
      provider?: string | undefined;
      include?: string[] | undefined;
      exclude?: string[] | undefined;
    }, {
      provider?: string | undefined;
      include?: string[] | undefined;
      exclude?: string[] | undefined;
    }>]>>>;
  }, "strip", ZodTypeAny, {
    roles: boolean | {
      provider?: string | undefined;
      include?: string[] | undefined;
      exclude?: string[] | undefined;
    };
  }, {
    roles?: boolean | {
      provider?: string | undefined;
      include?: string[] | undefined;
      exclude?: string[] | undefined;
    } | undefined;
  }>>;
};
type EntitiesFilter = TypeOf<typeof entitiesParams['entities']>;
type TablesFilter = TypeOf<typeof entitiesParams['tablesFilter']>;
type SchemasFilter = TypeOf<typeof entitiesParams['schemaFilter']>;
type ExtensionsFilter = TypeOf<typeof entitiesParams['extensionsFilters']>;
type EntitiesFilterConfig = {
  schemas: SchemasFilter;
  tables: TablesFilter;
  entities: EntitiesFilter;
  extensions: ExtensionsFilter;
};
//#endregion
//#region src/cli/validations/postgres.d.ts
declare const postgresCredentials: ZodUnion<[ZodEffects<ZodObject<{
  driver: ZodUndefined;
  host: ZodString;
  port: ZodOptional<ZodNumber>;
  user: ZodOptional<ZodString>;
  password: ZodOptional<ZodString>;
  database: ZodString;
  ssl: ZodOptional<ZodUnion<[ZodLiteral<"require">, ZodLiteral<"allow">, ZodLiteral<"prefer">, ZodLiteral<"verify-full">, ZodBoolean, ZodObject<{}, "passthrough", ZodTypeAny, objectOutputType<{}, ZodTypeAny, "passthrough">, objectInputType<{}, ZodTypeAny, "passthrough">>]>>;
}, "strip", ZodTypeAny, {
  host: string;
  database: string;
  password?: string | undefined;
  driver?: undefined;
  port?: number | undefined;
  user?: string | undefined;
  ssl?: boolean | "require" | "allow" | "prefer" | "verify-full" | objectOutputType<{}, ZodTypeAny, "passthrough"> | undefined;
}, {
  host: string;
  database: string;
  password?: string | undefined;
  driver?: undefined;
  port?: number | undefined;
  user?: string | undefined;
  ssl?: boolean | "require" | "allow" | "prefer" | "verify-full" | objectInputType<{}, ZodTypeAny, "passthrough"> | undefined;
}>, Omit<{
  host: string;
  database: string;
  password?: string | undefined;
  driver?: undefined;
  port?: number | undefined;
  user?: string | undefined;
  ssl?: boolean | "require" | "allow" | "prefer" | "verify-full" | objectOutputType<{}, ZodTypeAny, "passthrough"> | undefined;
}, "driver">, {
  host: string;
  database: string;
  password?: string | undefined;
  driver?: undefined;
  port?: number | undefined;
  user?: string | undefined;
  ssl?: boolean | "require" | "allow" | "prefer" | "verify-full" | objectInputType<{}, ZodTypeAny, "passthrough"> | undefined;
}>, ZodEffects<ZodObject<{
  driver: ZodUndefined;
  url: ZodString;
}, "strip", ZodTypeAny, {
  url: string;
  driver?: undefined;
}, {
  url: string;
  driver?: undefined;
}>, {
  url: string;
}, {
  url: string;
  driver?: undefined;
}>, ZodObject<{
  driver: ZodLiteral<"aws-data-api">;
  database: ZodString;
  secretArn: ZodString;
  resourceArn: ZodString;
}, "strip", ZodTypeAny, {
  driver: "aws-data-api";
  database: string;
  secretArn: string;
  resourceArn: string;
}, {
  driver: "aws-data-api";
  database: string;
  secretArn: string;
  resourceArn: string;
}>, ZodObject<{
  driver: ZodLiteral<"pglite">;
  url: ZodString;
}, "strip", ZodTypeAny, {
  driver: "pglite";
  url: string;
}, {
  driver: "pglite";
  url: string;
}>]>;
type PostgresCredentials = TypeOf<typeof postgresCredentials>;
//#endregion
//#region src/dialects/dialect.d.ts
type DataType = 'string' | 'string[]' | 'number' | 'boolean';
type TypeMap = {
  string: string;
  number: number;
  boolean: boolean;
  'string[]': string[];
};
type Simplify<T> = { [K in keyof T]: T[K] } & {};
type Assume<T, U> = T extends U ? T : U;
type ExtendedType = (`${Exclude<DataType, 'string[]'>}?` | DataType) | 'required' | [string, ...(string | null)[]] | {
  [K: string]: Exclude<ExtendedType, 'required'>;
} | ([{
  [K: string]: Exclude<ExtendedType, 'required'>;
}]);
type InferField<T extends ExtendedType> = T extends (string | null)[] ? T[number] : T extends [Record<string, ExtendedType>] ? { [K in keyof T[0]]: InferField<T[0][K]> }[] : T extends Record<string, ExtendedType> ? { [K in keyof T]: InferField<T[K]> } | null : T extends `${infer Type extends DataType}?` ? TypeMap[Type] | null : T extends DataType ? TypeMap[T] : never;
type Definition = Record<string, Schema>;
type InferSchema<TSchema extends Schema> = Simplify<{ -readonly [K in keyof TSchema]: K extends keyof Common ? Exclude<Common[K], null> : InferField<Assume<TSchema[K], ExtendedType>> }>;
type Schema = Record<string, ExtendedType> & { [K in keyof Common as null extends Common[K] ? K : never]?: 'required' } & { [K in keyof Common as null extends Common[K] ? never : K]?: never } & { [K in `${keyof Common}?`]?: never } & {
  entityType?: never;
  CONTAINS?: never;
};
type Common = {
  schema: string | null;
  table: string | null;
  name: string;
};
type CommonEntity = Common & {
  entityType: string;
};
type Config = {
  [K: string]: `${Exclude<DataType, 'string['>}?` | DataType | [string, ...string[]] | Config | [Config];
};
type ValueOf<T> = T[keyof T];
type DiffCreate<TSchema extends Definition = {}, TType extends keyof TSchema | 'entities' = string, TShape extends Record<string, any> = (TType extends 'entities' ? {} : Simplify<InferSchema<TSchema[TType]> & Omit<Common, keyof TSchema[TType]> & {
  entityType: TType;
}>)> = TType extends 'entities' ? ValueOf<{ [K in keyof TSchema]: DiffCreate<TSchema, K> }> : Simplify<{
  $diffType: 'create';
  entityType: TType;
} & { [K in keyof Common as K extends keyof TShape ? null extends TShape[K] ? never : K : K]: Exclude<Common[K], null> } & Omit<TShape, keyof CommonEntity>>;
type DiffDrop<TSchema extends Definition = {}, TType extends keyof TSchema | 'entities' = string, TShape extends Record<string, any> = (TType extends 'entities' ? {} : Simplify<InferSchema<TSchema[TType]> & Omit<Common, keyof TSchema[TType]> & {
  entityType: TType;
}>)> = TType extends 'entities' ? ValueOf<{ [K in keyof TSchema]: DiffDrop<TSchema, K> }> : Simplify<{
  $diffType: 'drop';
  entityType: TType;
} & { [K in keyof Common as K extends keyof TShape ? null extends TShape[K] ? never : K : K]: Exclude<Common[K], null> } & Omit<TShape, keyof CommonEntity>>;
type DiffAlter<TSchema extends Definition = {}, TType extends keyof TSchema | 'entities' = string, TShape extends Record<string, any> = (TType extends 'entities' ? {} : Simplify<InferSchema<TSchema[TType]> & Omit<Common, keyof TSchema[TType]> & {
  entityType: TType;
}>), TFullShape extends Record<string, any> = (TType extends 'entities' ? {} : Simplify<InferSchema<TSchema[TType]> & { [C in keyof Common as C extends keyof TSchema[TType] ? never : null extends Common[C] ? never : C]: Common[C] } & {
  entityType: TType;
}>)> = TType extends 'entities' ? ValueOf<{ [K in keyof TSchema]: DiffAlter<TSchema, K> }> : Simplify<{
  $diffType: 'alter';
  entityType: TType;
} & { [K in keyof Common as K extends keyof TShape ? null extends TShape[K] ? never : K : K]: Exclude<Common[K], null> } & { [K in Exclude<keyof TShape, keyof CommonEntity>]?: {
  from: TShape[K];
  to: TShape[K];
} } & {
  $left: TFullShape;
  $right: TFullShape;
}>;
type DiffStatement<TSchema extends Definition, TType extends keyof TSchema | 'entities'> = DiffCreate<TSchema, TType> | DiffDrop<TSchema, TType> | DiffAlter<TSchema, TType>;
//#endregion
//#region src/dialects/postgres/ddl.d.ts
declare const createDDL: () => {
  readonly _: {
    types: {
      schemas: {
        name: string;
        entityType: "schemas";
      };
      tables: {
        schema: string;
        isRlsEnabled: boolean;
        name: string;
        entityType: "tables";
      };
      enums: {
        schema: string;
        values: string[];
        name: string;
        entityType: "enums";
      };
      columns: {
        schema: string;
        table: string;
        type: string;
        typeSchema: string | null;
        notNull: boolean;
        dimensions: number;
        default: string | null;
        generated: {
          type: "stored";
          as: string;
        } | null;
        identity: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        name: string;
        entityType: "columns";
      };
      indexes: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        isUnique: boolean;
        where: string | null;
        with: string;
        method: string;
        concurrently: boolean;
        name: string;
        entityType: "indexes";
      };
      fks: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        name: string;
        entityType: "fks";
      };
      pks: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      };
      uniques: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        nullsNotDistinct: boolean;
        name: string;
        entityType: "uniques";
      };
      checks: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
      sequences: {
        schema: string;
        incrementBy: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cacheSize: number | null;
        cycle: boolean | null;
        name: string;
        entityType: "sequences";
      };
      roles: {
        superuser: boolean | null;
        createDb: boolean | null;
        createRole: boolean | null;
        inherit: boolean | null;
        canLogin: boolean | null;
        replication: boolean | null;
        bypassRls: boolean | null;
        connLimit: number | null;
        password: string | null;
        validUntil: string | null;
        name: string;
        entityType: "roles";
      };
      privileges: {
        grantor: string;
        grantee: string;
        schema: string;
        table: string;
        type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        isGrantable: boolean;
        name: string;
        entityType: "privileges";
      };
      policies: {
        schema: string;
        table: string;
        as: "PERMISSIVE" | "RESTRICTIVE";
        for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        roles: string[];
        using: string | null;
        withCheck: string | null;
        name: string;
        entityType: "policies";
      };
      views: {
        schema: string;
        definition: string | null;
        with: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        withNoData: boolean | null;
        using: string | null;
        tablespace: string | null;
        materialized: boolean;
        name: string;
        entityType: "views";
      };
    };
    definition: {
      schemas: {};
      tables: {
        schema: "required";
        isRlsEnabled: "boolean";
      };
      enums: {
        schema: "required";
        values: "string[]";
      };
      columns: {
        schema: "required";
        table: "required";
        type: "string";
        typeSchema: "string?";
        notNull: "boolean";
        dimensions: "number";
        default: "string?";
        generated: {
          type: ["stored"];
          as: "string";
        };
        identity: {
          name: "string";
          type: ["always", "byDefault"];
          increment: "string?";
          minValue: "string?";
          maxValue: "string?";
          startWith: "string?";
          cache: "number?";
          cycle: "boolean?";
        };
      };
      indexes: {
        schema: "required";
        table: "required";
        nameExplicit: "boolean";
        columns: [{
          value: "string";
          isExpression: "boolean";
          asc: "boolean";
          nullsFirst: "boolean";
          opclass: {
            name: "string";
            default: "boolean";
          };
        }];
        isUnique: "boolean";
        where: "string?";
        with: "string";
        method: "string";
        concurrently: "boolean";
      };
      fks: {
        schema: "required";
        table: "required";
        nameExplicit: "boolean";
        columns: "string[]";
        schemaTo: "string";
        tableTo: "string";
        columnsTo: "string[]";
        onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
        onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
      };
      pks: {
        schema: "required";
        table: "required";
        columns: "string[]";
        nameExplicit: "boolean";
      };
      uniques: {
        schema: "required";
        table: "required";
        nameExplicit: "boolean";
        columns: "string[]";
        nullsNotDistinct: "boolean";
      };
      checks: {
        schema: "required";
        table: "required";
        value: "string";
      };
      sequences: {
        schema: "required";
        incrementBy: "string?";
        minValue: "string?";
        maxValue: "string?";
        startWith: "string?";
        cacheSize: "number?";
        cycle: "boolean?";
      };
      roles: {
        superuser: "boolean?";
        createDb: "boolean?";
        createRole: "boolean?";
        inherit: "boolean?";
        canLogin: "boolean?";
        replication: "boolean?";
        bypassRls: "boolean?";
        connLimit: "number?";
        password: "string?";
        validUntil: "string?";
      };
      privileges: {
        grantor: "string";
        grantee: "string";
        schema: "required";
        table: "required";
        type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
        isGrantable: "boolean";
      };
      policies: {
        schema: "required";
        table: "required";
        as: ["PERMISSIVE", "RESTRICTIVE"];
        for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
        roles: "string[]";
        using: "string?";
        withCheck: "string?";
      };
      views: {
        schema: "required";
        definition: "string?";
        with: {
          checkOption: ["local", "cascaded", null];
          securityBarrier: "boolean?";
          securityInvoker: "boolean?";
          fillfactor: "number?";
          toastTupleTarget: "number?";
          parallelWorkers: "number?";
          autovacuumEnabled: "boolean?";
          vacuumIndexCleanup: ["auto", "off", "on", null];
          vacuumTruncate: "boolean?";
          autovacuumVacuumThreshold: "number?";
          autovacuumVacuumScaleFactor: "number?";
          autovacuumVacuumCostDelay: "number?";
          autovacuumVacuumCostLimit: "number?";
          autovacuumFreezeMinAge: "number?";
          autovacuumFreezeMaxAge: "number?";
          autovacuumFreezeTableAge: "number?";
          autovacuumMultixactFreezeMinAge: "number?";
          autovacuumMultixactFreezeMaxAge: "number?";
          autovacuumMultixactFreezeTableAge: "number?";
          logAutovacuumMinDuration: "number?";
          userCatalogTable: "boolean?";
        };
        withNoData: "boolean?";
        using: "string?";
        tablespace: "string?";
        materialized: "boolean";
      };
    };
    entities: {
      schemas: Config;
      tables: Config;
      enums: Config;
      columns: Config;
      indexes: Config;
      fks: Config;
      pks: Config;
      uniques: Config;
      checks: Config;
      sequences: Config;
      roles: Config;
      privileges: Config;
      policies: Config;
      views: Config;
    };
    diffs: {
      alter: {
        schemas: {
          $diffType: "alter";
          entityType: "schemas";
          name: string;
          $left: {
            name: string;
            entityType: "schemas";
          };
          $right: {
            name: string;
            entityType: "schemas";
          };
        };
        tables: {
          $diffType: "alter";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            isRlsEnabled: boolean;
            name: string;
            entityType: "tables";
          };
          $right: {
            schema: string;
            isRlsEnabled: boolean;
            name: string;
            entityType: "tables";
          };
        };
        enums: {
          $diffType: "alter";
          entityType: "enums";
          schema: string;
          name: string;
          values?: {
            from: string[];
            to: string[];
          } | undefined;
          $left: {
            schema: string;
            values: string[];
            name: string;
            entityType: "enums";
          };
          $right: {
            schema: string;
            values: string[];
            name: string;
            entityType: "enums";
          };
        };
        columns: {
          $diffType: "alter";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type?: {
            from: string;
            to: string;
          } | undefined;
          typeSchema?: {
            from: string | null;
            to: string | null;
          } | undefined;
          notNull?: {
            from: boolean;
            to: boolean;
          } | undefined;
          dimensions?: {
            from: number;
            to: number;
          } | undefined;
          default?: {
            from: string | null;
            to: string | null;
          } | undefined;
          generated?: {
            from: {
              type: "stored";
              as: string;
            } | null;
            to: {
              type: "stored";
              as: string;
            } | null;
          } | undefined;
          identity?: {
            from: {
              name: string;
              type: "always" | "byDefault";
              increment: string | null;
              minValue: string | null;
              maxValue: string | null;
              startWith: string | null;
              cache: number | null;
              cycle: boolean | null;
            } | null;
            to: {
              name: string;
              type: "always" | "byDefault";
              increment: string | null;
              minValue: string | null;
              maxValue: string | null;
              startWith: string | null;
              cache: number | null;
              cycle: boolean | null;
            } | null;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            type: string;
            typeSchema: string | null;
            notNull: boolean;
            dimensions: number;
            default: string | null;
            generated: {
              type: "stored";
              as: string;
            } | null;
            identity: {
              name: string;
              type: "always" | "byDefault";
              increment: string | null;
              minValue: string | null;
              maxValue: string | null;
              startWith: string | null;
              cache: number | null;
              cycle: boolean | null;
            } | null;
            name: string;
            entityType: "columns";
          };
          $right: {
            schema: string;
            table: string;
            type: string;
            typeSchema: string | null;
            notNull: boolean;
            dimensions: number;
            default: string | null;
            generated: {
              type: "stored";
              as: string;
            } | null;
            identity: {
              name: string;
              type: "always" | "byDefault";
              increment: string | null;
              minValue: string | null;
              maxValue: string | null;
              startWith: string | null;
              cache: number | null;
              cycle: boolean | null;
            } | null;
            name: string;
            entityType: "columns";
          };
        };
        indexes: {
          $diffType: "alter";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: {
              value: string;
              isExpression: boolean;
              asc: boolean;
              nullsFirst: boolean;
              opclass: {
                name: string;
                default: boolean;
              } | null;
            }[];
            to: {
              value: string;
              isExpression: boolean;
              asc: boolean;
              nullsFirst: boolean;
              opclass: {
                name: string;
                default: boolean;
              } | null;
            }[];
          } | undefined;
          with?: {
            from: string;
            to: string;
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          isUnique?: {
            from: boolean;
            to: boolean;
          } | undefined;
          where?: {
            from: string | null;
            to: string | null;
          } | undefined;
          method?: {
            from: string;
            to: string;
          } | undefined;
          concurrently?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: {
              value: string;
              isExpression: boolean;
              asc: boolean;
              nullsFirst: boolean;
              opclass: {
                name: string;
                default: boolean;
              } | null;
            }[];
            isUnique: boolean;
            where: string | null;
            with: string;
            method: string;
            concurrently: boolean;
            name: string;
            entityType: "indexes";
          };
          $right: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: {
              value: string;
              isExpression: boolean;
              asc: boolean;
              nullsFirst: boolean;
              opclass: {
                name: string;
                default: boolean;
              } | null;
            }[];
            isUnique: boolean;
            where: string | null;
            with: string;
            method: string;
            concurrently: boolean;
            name: string;
            entityType: "indexes";
          };
        };
        fks: {
          $diffType: "alter";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          schemaTo?: {
            from: string;
            to: string;
          } | undefined;
          tableTo?: {
            from: string;
            to: string;
          } | undefined;
          columnsTo?: {
            from: string[];
            to: string[];
          } | undefined;
          onUpdate?: {
            from: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
            to: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
          } | undefined;
          onDelete?: {
            from: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
            to: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            schemaTo: string;
            tableTo: string;
            columnsTo: string[];
            onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
            onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
            name: string;
            entityType: "fks";
          };
          $right: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            schemaTo: string;
            tableTo: string;
            columnsTo: string[];
            onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
            onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
            name: string;
            entityType: "fks";
          };
        };
        pks: {
          $diffType: "alter";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            columns: string[];
            nameExplicit: boolean;
            name: string;
            entityType: "pks";
          };
          $right: {
            schema: string;
            table: string;
            columns: string[];
            nameExplicit: boolean;
            name: string;
            entityType: "pks";
          };
        };
        uniques: {
          $diffType: "alter";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          nullsNotDistinct?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            nullsNotDistinct: boolean;
            name: string;
            entityType: "uniques";
          };
          $right: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            nullsNotDistinct: boolean;
            name: string;
            entityType: "uniques";
          };
        };
        checks: {
          $diffType: "alter";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value?: {
            from: string;
            to: string;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
          $right: {
            schema: string;
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
        };
        sequences: {
          $diffType: "alter";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue?: {
            from: string | null;
            to: string | null;
          } | undefined;
          maxValue?: {
            from: string | null;
            to: string | null;
          } | undefined;
          startWith?: {
            from: string | null;
            to: string | null;
          } | undefined;
          cycle?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          incrementBy?: {
            from: string | null;
            to: string | null;
          } | undefined;
          cacheSize?: {
            from: number | null;
            to: number | null;
          } | undefined;
          $left: {
            schema: string;
            incrementBy: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cacheSize: number | null;
            cycle: boolean | null;
            name: string;
            entityType: "sequences";
          };
          $right: {
            schema: string;
            incrementBy: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cacheSize: number | null;
            cycle: boolean | null;
            name: string;
            entityType: "sequences";
          };
        };
        roles: {
          $diffType: "alter";
          entityType: "roles";
          name: string;
          superuser?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          createDb?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          createRole?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          inherit?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          canLogin?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          replication?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          bypassRls?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          connLimit?: {
            from: number | null;
            to: number | null;
          } | undefined;
          password?: {
            from: string | null;
            to: string | null;
          } | undefined;
          validUntil?: {
            from: string | null;
            to: string | null;
          } | undefined;
          $left: {
            superuser: boolean | null;
            createDb: boolean | null;
            createRole: boolean | null;
            inherit: boolean | null;
            canLogin: boolean | null;
            replication: boolean | null;
            bypassRls: boolean | null;
            connLimit: number | null;
            password: string | null;
            validUntil: string | null;
            name: string;
            entityType: "roles";
          };
          $right: {
            superuser: boolean | null;
            createDb: boolean | null;
            createRole: boolean | null;
            inherit: boolean | null;
            canLogin: boolean | null;
            replication: boolean | null;
            bypassRls: boolean | null;
            connLimit: number | null;
            password: string | null;
            validUntil: string | null;
            name: string;
            entityType: "roles";
          };
        };
        privileges: {
          $diffType: "alter";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type?: {
            from: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
            to: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          } | undefined;
          grantor?: {
            from: string;
            to: string;
          } | undefined;
          grantee?: {
            from: string;
            to: string;
          } | undefined;
          isGrantable?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            grantor: string;
            grantee: string;
            schema: string;
            table: string;
            type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
            isGrantable: boolean;
            name: string;
            entityType: "privileges";
          };
          $right: {
            grantor: string;
            grantee: string;
            schema: string;
            table: string;
            type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
            isGrantable: boolean;
            name: string;
            entityType: "privileges";
          };
        };
        policies: {
          $diffType: "alter";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as?: {
            from: "PERMISSIVE" | "RESTRICTIVE";
            to: "PERMISSIVE" | "RESTRICTIVE";
          } | undefined;
          roles?: {
            from: string[];
            to: string[];
          } | undefined;
          for?: {
            from: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
            to: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          } | undefined;
          using?: {
            from: string | null;
            to: string | null;
          } | undefined;
          withCheck?: {
            from: string | null;
            to: string | null;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            as: "PERMISSIVE" | "RESTRICTIVE";
            for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
            roles: string[];
            using: string | null;
            withCheck: string | null;
            name: string;
            entityType: "policies";
          };
          $right: {
            schema: string;
            table: string;
            as: "PERMISSIVE" | "RESTRICTIVE";
            for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
            roles: string[];
            using: string | null;
            withCheck: string | null;
            name: string;
            entityType: "policies";
          };
        };
        views: {
          $diffType: "alter";
          entityType: "views";
          schema: string;
          name: string;
          with?: {
            from: {
              checkOption: "local" | "cascaded" | null;
              securityBarrier: boolean | null;
              securityInvoker: boolean | null;
              fillfactor: number | null;
              toastTupleTarget: number | null;
              parallelWorkers: number | null;
              autovacuumEnabled: boolean | null;
              vacuumIndexCleanup: "auto" | "off" | "on" | null;
              vacuumTruncate: boolean | null;
              autovacuumVacuumThreshold: number | null;
              autovacuumVacuumScaleFactor: number | null;
              autovacuumVacuumCostDelay: number | null;
              autovacuumVacuumCostLimit: number | null;
              autovacuumFreezeMinAge: number | null;
              autovacuumFreezeMaxAge: number | null;
              autovacuumFreezeTableAge: number | null;
              autovacuumMultixactFreezeMinAge: number | null;
              autovacuumMultixactFreezeMaxAge: number | null;
              autovacuumMultixactFreezeTableAge: number | null;
              logAutovacuumMinDuration: number | null;
              userCatalogTable: boolean | null;
            } | null;
            to: {
              checkOption: "local" | "cascaded" | null;
              securityBarrier: boolean | null;
              securityInvoker: boolean | null;
              fillfactor: number | null;
              toastTupleTarget: number | null;
              parallelWorkers: number | null;
              autovacuumEnabled: boolean | null;
              vacuumIndexCleanup: "auto" | "off" | "on" | null;
              vacuumTruncate: boolean | null;
              autovacuumVacuumThreshold: number | null;
              autovacuumVacuumScaleFactor: number | null;
              autovacuumVacuumCostDelay: number | null;
              autovacuumVacuumCostLimit: number | null;
              autovacuumFreezeMinAge: number | null;
              autovacuumFreezeMaxAge: number | null;
              autovacuumFreezeTableAge: number | null;
              autovacuumMultixactFreezeMinAge: number | null;
              autovacuumMultixactFreezeMaxAge: number | null;
              autovacuumMultixactFreezeTableAge: number | null;
              logAutovacuumMinDuration: number | null;
              userCatalogTable: boolean | null;
            } | null;
          } | undefined;
          using?: {
            from: string | null;
            to: string | null;
          } | undefined;
          definition?: {
            from: string | null;
            to: string | null;
          } | undefined;
          withNoData?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          tablespace?: {
            from: string | null;
            to: string | null;
          } | undefined;
          materialized?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            definition: string | null;
            with: {
              checkOption: "local" | "cascaded" | null;
              securityBarrier: boolean | null;
              securityInvoker: boolean | null;
              fillfactor: number | null;
              toastTupleTarget: number | null;
              parallelWorkers: number | null;
              autovacuumEnabled: boolean | null;
              vacuumIndexCleanup: "auto" | "off" | "on" | null;
              vacuumTruncate: boolean | null;
              autovacuumVacuumThreshold: number | null;
              autovacuumVacuumScaleFactor: number | null;
              autovacuumVacuumCostDelay: number | null;
              autovacuumVacuumCostLimit: number | null;
              autovacuumFreezeMinAge: number | null;
              autovacuumFreezeMaxAge: number | null;
              autovacuumFreezeTableAge: number | null;
              autovacuumMultixactFreezeMinAge: number | null;
              autovacuumMultixactFreezeMaxAge: number | null;
              autovacuumMultixactFreezeTableAge: number | null;
              logAutovacuumMinDuration: number | null;
              userCatalogTable: boolean | null;
            } | null;
            withNoData: boolean | null;
            using: string | null;
            tablespace: string | null;
            materialized: boolean;
            name: string;
            entityType: "views";
          };
          $right: {
            schema: string;
            definition: string | null;
            with: {
              checkOption: "local" | "cascaded" | null;
              securityBarrier: boolean | null;
              securityInvoker: boolean | null;
              fillfactor: number | null;
              toastTupleTarget: number | null;
              parallelWorkers: number | null;
              autovacuumEnabled: boolean | null;
              vacuumIndexCleanup: "auto" | "off" | "on" | null;
              vacuumTruncate: boolean | null;
              autovacuumVacuumThreshold: number | null;
              autovacuumVacuumScaleFactor: number | null;
              autovacuumVacuumCostDelay: number | null;
              autovacuumVacuumCostLimit: number | null;
              autovacuumFreezeMinAge: number | null;
              autovacuumFreezeMaxAge: number | null;
              autovacuumFreezeTableAge: number | null;
              autovacuumMultixactFreezeMinAge: number | null;
              autovacuumMultixactFreezeMaxAge: number | null;
              autovacuumMultixactFreezeTableAge: number | null;
              logAutovacuumMinDuration: number | null;
              userCatalogTable: boolean | null;
            } | null;
            withNoData: boolean | null;
            using: string | null;
            tablespace: string | null;
            materialized: boolean;
            name: string;
            entityType: "views";
          };
        };
        entities: {
          $diffType: "alter";
          entityType: "schemas";
          name: string;
          $left: {
            name: string;
            entityType: "schemas";
          };
          $right: {
            name: string;
            entityType: "schemas";
          };
        } | {
          $diffType: "alter";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            isRlsEnabled: boolean;
            name: string;
            entityType: "tables";
          };
          $right: {
            schema: string;
            isRlsEnabled: boolean;
            name: string;
            entityType: "tables";
          };
        } | {
          $diffType: "alter";
          entityType: "enums";
          schema: string;
          name: string;
          values?: {
            from: string[];
            to: string[];
          } | undefined;
          $left: {
            schema: string;
            values: string[];
            name: string;
            entityType: "enums";
          };
          $right: {
            schema: string;
            values: string[];
            name: string;
            entityType: "enums";
          };
        } | {
          $diffType: "alter";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type?: {
            from: string;
            to: string;
          } | undefined;
          typeSchema?: {
            from: string | null;
            to: string | null;
          } | undefined;
          notNull?: {
            from: boolean;
            to: boolean;
          } | undefined;
          dimensions?: {
            from: number;
            to: number;
          } | undefined;
          default?: {
            from: string | null;
            to: string | null;
          } | undefined;
          generated?: {
            from: {
              type: "stored";
              as: string;
            } | null;
            to: {
              type: "stored";
              as: string;
            } | null;
          } | undefined;
          identity?: {
            from: {
              name: string;
              type: "always" | "byDefault";
              increment: string | null;
              minValue: string | null;
              maxValue: string | null;
              startWith: string | null;
              cache: number | null;
              cycle: boolean | null;
            } | null;
            to: {
              name: string;
              type: "always" | "byDefault";
              increment: string | null;
              minValue: string | null;
              maxValue: string | null;
              startWith: string | null;
              cache: number | null;
              cycle: boolean | null;
            } | null;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            type: string;
            typeSchema: string | null;
            notNull: boolean;
            dimensions: number;
            default: string | null;
            generated: {
              type: "stored";
              as: string;
            } | null;
            identity: {
              name: string;
              type: "always" | "byDefault";
              increment: string | null;
              minValue: string | null;
              maxValue: string | null;
              startWith: string | null;
              cache: number | null;
              cycle: boolean | null;
            } | null;
            name: string;
            entityType: "columns";
          };
          $right: {
            schema: string;
            table: string;
            type: string;
            typeSchema: string | null;
            notNull: boolean;
            dimensions: number;
            default: string | null;
            generated: {
              type: "stored";
              as: string;
            } | null;
            identity: {
              name: string;
              type: "always" | "byDefault";
              increment: string | null;
              minValue: string | null;
              maxValue: string | null;
              startWith: string | null;
              cache: number | null;
              cycle: boolean | null;
            } | null;
            name: string;
            entityType: "columns";
          };
        } | {
          $diffType: "alter";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: {
              value: string;
              isExpression: boolean;
              asc: boolean;
              nullsFirst: boolean;
              opclass: {
                name: string;
                default: boolean;
              } | null;
            }[];
            to: {
              value: string;
              isExpression: boolean;
              asc: boolean;
              nullsFirst: boolean;
              opclass: {
                name: string;
                default: boolean;
              } | null;
            }[];
          } | undefined;
          with?: {
            from: string;
            to: string;
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          isUnique?: {
            from: boolean;
            to: boolean;
          } | undefined;
          where?: {
            from: string | null;
            to: string | null;
          } | undefined;
          method?: {
            from: string;
            to: string;
          } | undefined;
          concurrently?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: {
              value: string;
              isExpression: boolean;
              asc: boolean;
              nullsFirst: boolean;
              opclass: {
                name: string;
                default: boolean;
              } | null;
            }[];
            isUnique: boolean;
            where: string | null;
            with: string;
            method: string;
            concurrently: boolean;
            name: string;
            entityType: "indexes";
          };
          $right: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: {
              value: string;
              isExpression: boolean;
              asc: boolean;
              nullsFirst: boolean;
              opclass: {
                name: string;
                default: boolean;
              } | null;
            }[];
            isUnique: boolean;
            where: string | null;
            with: string;
            method: string;
            concurrently: boolean;
            name: string;
            entityType: "indexes";
          };
        } | {
          $diffType: "alter";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          schemaTo?: {
            from: string;
            to: string;
          } | undefined;
          tableTo?: {
            from: string;
            to: string;
          } | undefined;
          columnsTo?: {
            from: string[];
            to: string[];
          } | undefined;
          onUpdate?: {
            from: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
            to: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
          } | undefined;
          onDelete?: {
            from: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
            to: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            schemaTo: string;
            tableTo: string;
            columnsTo: string[];
            onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
            onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
            name: string;
            entityType: "fks";
          };
          $right: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            schemaTo: string;
            tableTo: string;
            columnsTo: string[];
            onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
            onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
            name: string;
            entityType: "fks";
          };
        } | {
          $diffType: "alter";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            columns: string[];
            nameExplicit: boolean;
            name: string;
            entityType: "pks";
          };
          $right: {
            schema: string;
            table: string;
            columns: string[];
            nameExplicit: boolean;
            name: string;
            entityType: "pks";
          };
        } | {
          $diffType: "alter";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          nullsNotDistinct?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            nullsNotDistinct: boolean;
            name: string;
            entityType: "uniques";
          };
          $right: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            nullsNotDistinct: boolean;
            name: string;
            entityType: "uniques";
          };
        } | {
          $diffType: "alter";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value?: {
            from: string;
            to: string;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
          $right: {
            schema: string;
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
        } | {
          $diffType: "alter";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue?: {
            from: string | null;
            to: string | null;
          } | undefined;
          maxValue?: {
            from: string | null;
            to: string | null;
          } | undefined;
          startWith?: {
            from: string | null;
            to: string | null;
          } | undefined;
          cycle?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          incrementBy?: {
            from: string | null;
            to: string | null;
          } | undefined;
          cacheSize?: {
            from: number | null;
            to: number | null;
          } | undefined;
          $left: {
            schema: string;
            incrementBy: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cacheSize: number | null;
            cycle: boolean | null;
            name: string;
            entityType: "sequences";
          };
          $right: {
            schema: string;
            incrementBy: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cacheSize: number | null;
            cycle: boolean | null;
            name: string;
            entityType: "sequences";
          };
        } | {
          $diffType: "alter";
          entityType: "roles";
          name: string;
          superuser?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          createDb?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          createRole?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          inherit?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          canLogin?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          replication?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          bypassRls?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          connLimit?: {
            from: number | null;
            to: number | null;
          } | undefined;
          password?: {
            from: string | null;
            to: string | null;
          } | undefined;
          validUntil?: {
            from: string | null;
            to: string | null;
          } | undefined;
          $left: {
            superuser: boolean | null;
            createDb: boolean | null;
            createRole: boolean | null;
            inherit: boolean | null;
            canLogin: boolean | null;
            replication: boolean | null;
            bypassRls: boolean | null;
            connLimit: number | null;
            password: string | null;
            validUntil: string | null;
            name: string;
            entityType: "roles";
          };
          $right: {
            superuser: boolean | null;
            createDb: boolean | null;
            createRole: boolean | null;
            inherit: boolean | null;
            canLogin: boolean | null;
            replication: boolean | null;
            bypassRls: boolean | null;
            connLimit: number | null;
            password: string | null;
            validUntil: string | null;
            name: string;
            entityType: "roles";
          };
        } | {
          $diffType: "alter";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type?: {
            from: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
            to: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          } | undefined;
          grantor?: {
            from: string;
            to: string;
          } | undefined;
          grantee?: {
            from: string;
            to: string;
          } | undefined;
          isGrantable?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            grantor: string;
            grantee: string;
            schema: string;
            table: string;
            type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
            isGrantable: boolean;
            name: string;
            entityType: "privileges";
          };
          $right: {
            grantor: string;
            grantee: string;
            schema: string;
            table: string;
            type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
            isGrantable: boolean;
            name: string;
            entityType: "privileges";
          };
        } | {
          $diffType: "alter";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as?: {
            from: "PERMISSIVE" | "RESTRICTIVE";
            to: "PERMISSIVE" | "RESTRICTIVE";
          } | undefined;
          roles?: {
            from: string[];
            to: string[];
          } | undefined;
          for?: {
            from: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
            to: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          } | undefined;
          using?: {
            from: string | null;
            to: string | null;
          } | undefined;
          withCheck?: {
            from: string | null;
            to: string | null;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            as: "PERMISSIVE" | "RESTRICTIVE";
            for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
            roles: string[];
            using: string | null;
            withCheck: string | null;
            name: string;
            entityType: "policies";
          };
          $right: {
            schema: string;
            table: string;
            as: "PERMISSIVE" | "RESTRICTIVE";
            for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
            roles: string[];
            using: string | null;
            withCheck: string | null;
            name: string;
            entityType: "policies";
          };
        } | {
          $diffType: "alter";
          entityType: "views";
          schema: string;
          name: string;
          with?: {
            from: {
              checkOption: "local" | "cascaded" | null;
              securityBarrier: boolean | null;
              securityInvoker: boolean | null;
              fillfactor: number | null;
              toastTupleTarget: number | null;
              parallelWorkers: number | null;
              autovacuumEnabled: boolean | null;
              vacuumIndexCleanup: "auto" | "off" | "on" | null;
              vacuumTruncate: boolean | null;
              autovacuumVacuumThreshold: number | null;
              autovacuumVacuumScaleFactor: number | null;
              autovacuumVacuumCostDelay: number | null;
              autovacuumVacuumCostLimit: number | null;
              autovacuumFreezeMinAge: number | null;
              autovacuumFreezeMaxAge: number | null;
              autovacuumFreezeTableAge: number | null;
              autovacuumMultixactFreezeMinAge: number | null;
              autovacuumMultixactFreezeMaxAge: number | null;
              autovacuumMultixactFreezeTableAge: number | null;
              logAutovacuumMinDuration: number | null;
              userCatalogTable: boolean | null;
            } | null;
            to: {
              checkOption: "local" | "cascaded" | null;
              securityBarrier: boolean | null;
              securityInvoker: boolean | null;
              fillfactor: number | null;
              toastTupleTarget: number | null;
              parallelWorkers: number | null;
              autovacuumEnabled: boolean | null;
              vacuumIndexCleanup: "auto" | "off" | "on" | null;
              vacuumTruncate: boolean | null;
              autovacuumVacuumThreshold: number | null;
              autovacuumVacuumScaleFactor: number | null;
              autovacuumVacuumCostDelay: number | null;
              autovacuumVacuumCostLimit: number | null;
              autovacuumFreezeMinAge: number | null;
              autovacuumFreezeMaxAge: number | null;
              autovacuumFreezeTableAge: number | null;
              autovacuumMultixactFreezeMinAge: number | null;
              autovacuumMultixactFreezeMaxAge: number | null;
              autovacuumMultixactFreezeTableAge: number | null;
              logAutovacuumMinDuration: number | null;
              userCatalogTable: boolean | null;
            } | null;
          } | undefined;
          using?: {
            from: string | null;
            to: string | null;
          } | undefined;
          definition?: {
            from: string | null;
            to: string | null;
          } | undefined;
          withNoData?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          tablespace?: {
            from: string | null;
            to: string | null;
          } | undefined;
          materialized?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            definition: string | null;
            with: {
              checkOption: "local" | "cascaded" | null;
              securityBarrier: boolean | null;
              securityInvoker: boolean | null;
              fillfactor: number | null;
              toastTupleTarget: number | null;
              parallelWorkers: number | null;
              autovacuumEnabled: boolean | null;
              vacuumIndexCleanup: "auto" | "off" | "on" | null;
              vacuumTruncate: boolean | null;
              autovacuumVacuumThreshold: number | null;
              autovacuumVacuumScaleFactor: number | null;
              autovacuumVacuumCostDelay: number | null;
              autovacuumVacuumCostLimit: number | null;
              autovacuumFreezeMinAge: number | null;
              autovacuumFreezeMaxAge: number | null;
              autovacuumFreezeTableAge: number | null;
              autovacuumMultixactFreezeMinAge: number | null;
              autovacuumMultixactFreezeMaxAge: number | null;
              autovacuumMultixactFreezeTableAge: number | null;
              logAutovacuumMinDuration: number | null;
              userCatalogTable: boolean | null;
            } | null;
            withNoData: boolean | null;
            using: string | null;
            tablespace: string | null;
            materialized: boolean;
            name: string;
            entityType: "views";
          };
          $right: {
            schema: string;
            definition: string | null;
            with: {
              checkOption: "local" | "cascaded" | null;
              securityBarrier: boolean | null;
              securityInvoker: boolean | null;
              fillfactor: number | null;
              toastTupleTarget: number | null;
              parallelWorkers: number | null;
              autovacuumEnabled: boolean | null;
              vacuumIndexCleanup: "auto" | "off" | "on" | null;
              vacuumTruncate: boolean | null;
              autovacuumVacuumThreshold: number | null;
              autovacuumVacuumScaleFactor: number | null;
              autovacuumVacuumCostDelay: number | null;
              autovacuumVacuumCostLimit: number | null;
              autovacuumFreezeMinAge: number | null;
              autovacuumFreezeMaxAge: number | null;
              autovacuumFreezeTableAge: number | null;
              autovacuumMultixactFreezeMinAge: number | null;
              autovacuumMultixactFreezeMaxAge: number | null;
              autovacuumMultixactFreezeTableAge: number | null;
              logAutovacuumMinDuration: number | null;
              userCatalogTable: boolean | null;
            } | null;
            withNoData: boolean | null;
            using: string | null;
            tablespace: string | null;
            materialized: boolean;
            name: string;
            entityType: "views";
          };
        };
      };
      create: {
        schemas: {
          $diffType: "create";
          entityType: "schemas";
          name: string;
        };
        tables: {
          $diffType: "create";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled: boolean;
        };
        enums: {
          $diffType: "create";
          entityType: "enums";
          schema: string;
          name: string;
          values: string[];
        };
        columns: {
          $diffType: "create";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          typeSchema: string | null;
          notNull: boolean;
          dimensions: number;
          default: string | null;
          generated: {
            type: "stored";
            as: string;
          } | null;
          identity: {
            name: string;
            type: "always" | "byDefault";
            increment: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cache: number | null;
            cycle: boolean | null;
          } | null;
        };
        indexes: {
          $diffType: "create";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          }[];
          with: string;
          nameExplicit: boolean;
          isUnique: boolean;
          where: string | null;
          method: string;
          concurrently: boolean;
        };
        fks: {
          $diffType: "create";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
          onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        };
        pks: {
          $diffType: "create";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        };
        uniques: {
          $diffType: "create";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          nullsNotDistinct: boolean;
        };
        checks: {
          $diffType: "create";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        };
        sequences: {
          $diffType: "create";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cycle: boolean | null;
          incrementBy: string | null;
          cacheSize: number | null;
        };
        roles: {
          $diffType: "create";
          entityType: "roles";
          name: string;
          superuser: boolean | null;
          createDb: boolean | null;
          createRole: boolean | null;
          inherit: boolean | null;
          canLogin: boolean | null;
          replication: boolean | null;
          bypassRls: boolean | null;
          connLimit: number | null;
          password: string | null;
          validUntil: string | null;
        };
        privileges: {
          $diffType: "create";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          grantor: string;
          grantee: string;
          isGrantable: boolean;
        };
        policies: {
          $diffType: "create";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as: "PERMISSIVE" | "RESTRICTIVE";
          roles: string[];
          for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          using: string | null;
          withCheck: string | null;
        };
        views: {
          $diffType: "create";
          entityType: "views";
          schema: string;
          name: string;
          with: {
            checkOption: "local" | "cascaded" | null;
            securityBarrier: boolean | null;
            securityInvoker: boolean | null;
            fillfactor: number | null;
            toastTupleTarget: number | null;
            parallelWorkers: number | null;
            autovacuumEnabled: boolean | null;
            vacuumIndexCleanup: "auto" | "off" | "on" | null;
            vacuumTruncate: boolean | null;
            autovacuumVacuumThreshold: number | null;
            autovacuumVacuumScaleFactor: number | null;
            autovacuumVacuumCostDelay: number | null;
            autovacuumVacuumCostLimit: number | null;
            autovacuumFreezeMinAge: number | null;
            autovacuumFreezeMaxAge: number | null;
            autovacuumFreezeTableAge: number | null;
            autovacuumMultixactFreezeMinAge: number | null;
            autovacuumMultixactFreezeMaxAge: number | null;
            autovacuumMultixactFreezeTableAge: number | null;
            logAutovacuumMinDuration: number | null;
            userCatalogTable: boolean | null;
          } | null;
          using: string | null;
          definition: string | null;
          withNoData: boolean | null;
          tablespace: string | null;
          materialized: boolean;
        };
        entities: {
          $diffType: "create";
          entityType: "schemas";
          name: string;
        } | {
          $diffType: "create";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled: boolean;
        } | {
          $diffType: "create";
          entityType: "enums";
          schema: string;
          name: string;
          values: string[];
        } | {
          $diffType: "create";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          typeSchema: string | null;
          notNull: boolean;
          dimensions: number;
          default: string | null;
          generated: {
            type: "stored";
            as: string;
          } | null;
          identity: {
            name: string;
            type: "always" | "byDefault";
            increment: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cache: number | null;
            cycle: boolean | null;
          } | null;
        } | {
          $diffType: "create";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          }[];
          with: string;
          nameExplicit: boolean;
          isUnique: boolean;
          where: string | null;
          method: string;
          concurrently: boolean;
        } | {
          $diffType: "create";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
          onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        } | {
          $diffType: "create";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "create";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          nullsNotDistinct: boolean;
        } | {
          $diffType: "create";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "create";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cycle: boolean | null;
          incrementBy: string | null;
          cacheSize: number | null;
        } | {
          $diffType: "create";
          entityType: "roles";
          name: string;
          superuser: boolean | null;
          createDb: boolean | null;
          createRole: boolean | null;
          inherit: boolean | null;
          canLogin: boolean | null;
          replication: boolean | null;
          bypassRls: boolean | null;
          connLimit: number | null;
          password: string | null;
          validUntil: string | null;
        } | {
          $diffType: "create";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          grantor: string;
          grantee: string;
          isGrantable: boolean;
        } | {
          $diffType: "create";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as: "PERMISSIVE" | "RESTRICTIVE";
          roles: string[];
          for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          using: string | null;
          withCheck: string | null;
        } | {
          $diffType: "create";
          entityType: "views";
          schema: string;
          name: string;
          with: {
            checkOption: "local" | "cascaded" | null;
            securityBarrier: boolean | null;
            securityInvoker: boolean | null;
            fillfactor: number | null;
            toastTupleTarget: number | null;
            parallelWorkers: number | null;
            autovacuumEnabled: boolean | null;
            vacuumIndexCleanup: "auto" | "off" | "on" | null;
            vacuumTruncate: boolean | null;
            autovacuumVacuumThreshold: number | null;
            autovacuumVacuumScaleFactor: number | null;
            autovacuumVacuumCostDelay: number | null;
            autovacuumVacuumCostLimit: number | null;
            autovacuumFreezeMinAge: number | null;
            autovacuumFreezeMaxAge: number | null;
            autovacuumFreezeTableAge: number | null;
            autovacuumMultixactFreezeMinAge: number | null;
            autovacuumMultixactFreezeMaxAge: number | null;
            autovacuumMultixactFreezeTableAge: number | null;
            logAutovacuumMinDuration: number | null;
            userCatalogTable: boolean | null;
          } | null;
          using: string | null;
          definition: string | null;
          withNoData: boolean | null;
          tablespace: string | null;
          materialized: boolean;
        };
      };
      drop: {
        schemas: {
          $diffType: "drop";
          entityType: "schemas";
          name: string;
        };
        tables: {
          $diffType: "drop";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled: boolean;
        };
        enums: {
          $diffType: "drop";
          entityType: "enums";
          schema: string;
          name: string;
          values: string[];
        };
        columns: {
          $diffType: "drop";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          typeSchema: string | null;
          notNull: boolean;
          dimensions: number;
          default: string | null;
          generated: {
            type: "stored";
            as: string;
          } | null;
          identity: {
            name: string;
            type: "always" | "byDefault";
            increment: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cache: number | null;
            cycle: boolean | null;
          } | null;
        };
        indexes: {
          $diffType: "drop";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          }[];
          with: string;
          nameExplicit: boolean;
          isUnique: boolean;
          where: string | null;
          method: string;
          concurrently: boolean;
        };
        fks: {
          $diffType: "drop";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
          onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        };
        pks: {
          $diffType: "drop";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        };
        uniques: {
          $diffType: "drop";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          nullsNotDistinct: boolean;
        };
        checks: {
          $diffType: "drop";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        };
        sequences: {
          $diffType: "drop";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cycle: boolean | null;
          incrementBy: string | null;
          cacheSize: number | null;
        };
        roles: {
          $diffType: "drop";
          entityType: "roles";
          name: string;
          superuser: boolean | null;
          createDb: boolean | null;
          createRole: boolean | null;
          inherit: boolean | null;
          canLogin: boolean | null;
          replication: boolean | null;
          bypassRls: boolean | null;
          connLimit: number | null;
          password: string | null;
          validUntil: string | null;
        };
        privileges: {
          $diffType: "drop";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          grantor: string;
          grantee: string;
          isGrantable: boolean;
        };
        policies: {
          $diffType: "drop";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as: "PERMISSIVE" | "RESTRICTIVE";
          roles: string[];
          for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          using: string | null;
          withCheck: string | null;
        };
        views: {
          $diffType: "drop";
          entityType: "views";
          schema: string;
          name: string;
          with: {
            checkOption: "local" | "cascaded" | null;
            securityBarrier: boolean | null;
            securityInvoker: boolean | null;
            fillfactor: number | null;
            toastTupleTarget: number | null;
            parallelWorkers: number | null;
            autovacuumEnabled: boolean | null;
            vacuumIndexCleanup: "auto" | "off" | "on" | null;
            vacuumTruncate: boolean | null;
            autovacuumVacuumThreshold: number | null;
            autovacuumVacuumScaleFactor: number | null;
            autovacuumVacuumCostDelay: number | null;
            autovacuumVacuumCostLimit: number | null;
            autovacuumFreezeMinAge: number | null;
            autovacuumFreezeMaxAge: number | null;
            autovacuumFreezeTableAge: number | null;
            autovacuumMultixactFreezeMinAge: number | null;
            autovacuumMultixactFreezeMaxAge: number | null;
            autovacuumMultixactFreezeTableAge: number | null;
            logAutovacuumMinDuration: number | null;
            userCatalogTable: boolean | null;
          } | null;
          using: string | null;
          definition: string | null;
          withNoData: boolean | null;
          tablespace: string | null;
          materialized: boolean;
        };
        entities: {
          $diffType: "drop";
          entityType: "schemas";
          name: string;
        } | {
          $diffType: "drop";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled: boolean;
        } | {
          $diffType: "drop";
          entityType: "enums";
          schema: string;
          name: string;
          values: string[];
        } | {
          $diffType: "drop";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          typeSchema: string | null;
          notNull: boolean;
          dimensions: number;
          default: string | null;
          generated: {
            type: "stored";
            as: string;
          } | null;
          identity: {
            name: string;
            type: "always" | "byDefault";
            increment: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cache: number | null;
            cycle: boolean | null;
          } | null;
        } | {
          $diffType: "drop";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          }[];
          with: string;
          nameExplicit: boolean;
          isUnique: boolean;
          where: string | null;
          method: string;
          concurrently: boolean;
        } | {
          $diffType: "drop";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
          onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        } | {
          $diffType: "drop";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "drop";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          nullsNotDistinct: boolean;
        } | {
          $diffType: "drop";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "drop";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cycle: boolean | null;
          incrementBy: string | null;
          cacheSize: number | null;
        } | {
          $diffType: "drop";
          entityType: "roles";
          name: string;
          superuser: boolean | null;
          createDb: boolean | null;
          createRole: boolean | null;
          inherit: boolean | null;
          canLogin: boolean | null;
          replication: boolean | null;
          bypassRls: boolean | null;
          connLimit: number | null;
          password: string | null;
          validUntil: string | null;
        } | {
          $diffType: "drop";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          grantor: string;
          grantee: string;
          isGrantable: boolean;
        } | {
          $diffType: "drop";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as: "PERMISSIVE" | "RESTRICTIVE";
          roles: string[];
          for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          using: string | null;
          withCheck: string | null;
        } | {
          $diffType: "drop";
          entityType: "views";
          schema: string;
          name: string;
          with: {
            checkOption: "local" | "cascaded" | null;
            securityBarrier: boolean | null;
            securityInvoker: boolean | null;
            fillfactor: number | null;
            toastTupleTarget: number | null;
            parallelWorkers: number | null;
            autovacuumEnabled: boolean | null;
            vacuumIndexCleanup: "auto" | "off" | "on" | null;
            vacuumTruncate: boolean | null;
            autovacuumVacuumThreshold: number | null;
            autovacuumVacuumScaleFactor: number | null;
            autovacuumVacuumCostDelay: number | null;
            autovacuumVacuumCostLimit: number | null;
            autovacuumFreezeMinAge: number | null;
            autovacuumFreezeMaxAge: number | null;
            autovacuumFreezeTableAge: number | null;
            autovacuumMultixactFreezeMinAge: number | null;
            autovacuumMultixactFreezeMaxAge: number | null;
            autovacuumMultixactFreezeTableAge: number | null;
            logAutovacuumMinDuration: number | null;
            userCatalogTable: boolean | null;
          } | null;
          using: string | null;
          definition: string | null;
          withNoData: boolean | null;
          tablespace: string | null;
          materialized: boolean;
        };
      };
      createdrop: {
        schemas: {
          $diffType: "create";
          entityType: "schemas";
          name: string;
        } | {
          $diffType: "drop";
          entityType: "schemas";
          name: string;
        };
        tables: {
          $diffType: "create";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled: boolean;
        } | {
          $diffType: "drop";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled: boolean;
        };
        enums: {
          $diffType: "create";
          entityType: "enums";
          schema: string;
          name: string;
          values: string[];
        } | {
          $diffType: "drop";
          entityType: "enums";
          schema: string;
          name: string;
          values: string[];
        };
        columns: {
          $diffType: "create";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          typeSchema: string | null;
          notNull: boolean;
          dimensions: number;
          default: string | null;
          generated: {
            type: "stored";
            as: string;
          } | null;
          identity: {
            name: string;
            type: "always" | "byDefault";
            increment: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cache: number | null;
            cycle: boolean | null;
          } | null;
        } | {
          $diffType: "drop";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          typeSchema: string | null;
          notNull: boolean;
          dimensions: number;
          default: string | null;
          generated: {
            type: "stored";
            as: string;
          } | null;
          identity: {
            name: string;
            type: "always" | "byDefault";
            increment: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cache: number | null;
            cycle: boolean | null;
          } | null;
        };
        indexes: {
          $diffType: "create";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          }[];
          with: string;
          nameExplicit: boolean;
          isUnique: boolean;
          where: string | null;
          method: string;
          concurrently: boolean;
        } | {
          $diffType: "drop";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          }[];
          with: string;
          nameExplicit: boolean;
          isUnique: boolean;
          where: string | null;
          method: string;
          concurrently: boolean;
        };
        fks: {
          $diffType: "create";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
          onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        } | {
          $diffType: "drop";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
          onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        };
        pks: {
          $diffType: "create";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "drop";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        };
        uniques: {
          $diffType: "create";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          nullsNotDistinct: boolean;
        } | {
          $diffType: "drop";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          nullsNotDistinct: boolean;
        };
        checks: {
          $diffType: "create";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "drop";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        };
        sequences: {
          $diffType: "create";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cycle: boolean | null;
          incrementBy: string | null;
          cacheSize: number | null;
        } | {
          $diffType: "drop";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cycle: boolean | null;
          incrementBy: string | null;
          cacheSize: number | null;
        };
        roles: {
          $diffType: "create";
          entityType: "roles";
          name: string;
          superuser: boolean | null;
          createDb: boolean | null;
          createRole: boolean | null;
          inherit: boolean | null;
          canLogin: boolean | null;
          replication: boolean | null;
          bypassRls: boolean | null;
          connLimit: number | null;
          password: string | null;
          validUntil: string | null;
        } | {
          $diffType: "drop";
          entityType: "roles";
          name: string;
          superuser: boolean | null;
          createDb: boolean | null;
          createRole: boolean | null;
          inherit: boolean | null;
          canLogin: boolean | null;
          replication: boolean | null;
          bypassRls: boolean | null;
          connLimit: number | null;
          password: string | null;
          validUntil: string | null;
        };
        privileges: {
          $diffType: "create";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          grantor: string;
          grantee: string;
          isGrantable: boolean;
        } | {
          $diffType: "drop";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          grantor: string;
          grantee: string;
          isGrantable: boolean;
        };
        policies: {
          $diffType: "create";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as: "PERMISSIVE" | "RESTRICTIVE";
          roles: string[];
          for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          using: string | null;
          withCheck: string | null;
        } | {
          $diffType: "drop";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as: "PERMISSIVE" | "RESTRICTIVE";
          roles: string[];
          for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          using: string | null;
          withCheck: string | null;
        };
        views: {
          $diffType: "create";
          entityType: "views";
          schema: string;
          name: string;
          with: {
            checkOption: "local" | "cascaded" | null;
            securityBarrier: boolean | null;
            securityInvoker: boolean | null;
            fillfactor: number | null;
            toastTupleTarget: number | null;
            parallelWorkers: number | null;
            autovacuumEnabled: boolean | null;
            vacuumIndexCleanup: "auto" | "off" | "on" | null;
            vacuumTruncate: boolean | null;
            autovacuumVacuumThreshold: number | null;
            autovacuumVacuumScaleFactor: number | null;
            autovacuumVacuumCostDelay: number | null;
            autovacuumVacuumCostLimit: number | null;
            autovacuumFreezeMinAge: number | null;
            autovacuumFreezeMaxAge: number | null;
            autovacuumFreezeTableAge: number | null;
            autovacuumMultixactFreezeMinAge: number | null;
            autovacuumMultixactFreezeMaxAge: number | null;
            autovacuumMultixactFreezeTableAge: number | null;
            logAutovacuumMinDuration: number | null;
            userCatalogTable: boolean | null;
          } | null;
          using: string | null;
          definition: string | null;
          withNoData: boolean | null;
          tablespace: string | null;
          materialized: boolean;
        } | {
          $diffType: "drop";
          entityType: "views";
          schema: string;
          name: string;
          with: {
            checkOption: "local" | "cascaded" | null;
            securityBarrier: boolean | null;
            securityInvoker: boolean | null;
            fillfactor: number | null;
            toastTupleTarget: number | null;
            parallelWorkers: number | null;
            autovacuumEnabled: boolean | null;
            vacuumIndexCleanup: "auto" | "off" | "on" | null;
            vacuumTruncate: boolean | null;
            autovacuumVacuumThreshold: number | null;
            autovacuumVacuumScaleFactor: number | null;
            autovacuumVacuumCostDelay: number | null;
            autovacuumVacuumCostLimit: number | null;
            autovacuumFreezeMinAge: number | null;
            autovacuumFreezeMaxAge: number | null;
            autovacuumFreezeTableAge: number | null;
            autovacuumMultixactFreezeMinAge: number | null;
            autovacuumMultixactFreezeMaxAge: number | null;
            autovacuumMultixactFreezeTableAge: number | null;
            logAutovacuumMinDuration: number | null;
            userCatalogTable: boolean | null;
          } | null;
          using: string | null;
          definition: string | null;
          withNoData: boolean | null;
          tablespace: string | null;
          materialized: boolean;
        };
        entities: ({
          $diffType: "create";
          entityType: "schemas";
          name: string;
        } | {
          $diffType: "create";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled: boolean;
        } | {
          $diffType: "create";
          entityType: "enums";
          schema: string;
          name: string;
          values: string[];
        } | {
          $diffType: "create";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          typeSchema: string | null;
          notNull: boolean;
          dimensions: number;
          default: string | null;
          generated: {
            type: "stored";
            as: string;
          } | null;
          identity: {
            name: string;
            type: "always" | "byDefault";
            increment: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cache: number | null;
            cycle: boolean | null;
          } | null;
        } | {
          $diffType: "create";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          }[];
          with: string;
          nameExplicit: boolean;
          isUnique: boolean;
          where: string | null;
          method: string;
          concurrently: boolean;
        } | {
          $diffType: "create";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
          onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        } | {
          $diffType: "create";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "create";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          nullsNotDistinct: boolean;
        } | {
          $diffType: "create";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "create";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cycle: boolean | null;
          incrementBy: string | null;
          cacheSize: number | null;
        } | {
          $diffType: "create";
          entityType: "roles";
          name: string;
          superuser: boolean | null;
          createDb: boolean | null;
          createRole: boolean | null;
          inherit: boolean | null;
          canLogin: boolean | null;
          replication: boolean | null;
          bypassRls: boolean | null;
          connLimit: number | null;
          password: string | null;
          validUntil: string | null;
        } | {
          $diffType: "create";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          grantor: string;
          grantee: string;
          isGrantable: boolean;
        } | {
          $diffType: "create";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as: "PERMISSIVE" | "RESTRICTIVE";
          roles: string[];
          for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          using: string | null;
          withCheck: string | null;
        } | {
          $diffType: "create";
          entityType: "views";
          schema: string;
          name: string;
          with: {
            checkOption: "local" | "cascaded" | null;
            securityBarrier: boolean | null;
            securityInvoker: boolean | null;
            fillfactor: number | null;
            toastTupleTarget: number | null;
            parallelWorkers: number | null;
            autovacuumEnabled: boolean | null;
            vacuumIndexCleanup: "auto" | "off" | "on" | null;
            vacuumTruncate: boolean | null;
            autovacuumVacuumThreshold: number | null;
            autovacuumVacuumScaleFactor: number | null;
            autovacuumVacuumCostDelay: number | null;
            autovacuumVacuumCostLimit: number | null;
            autovacuumFreezeMinAge: number | null;
            autovacuumFreezeMaxAge: number | null;
            autovacuumFreezeTableAge: number | null;
            autovacuumMultixactFreezeMinAge: number | null;
            autovacuumMultixactFreezeMaxAge: number | null;
            autovacuumMultixactFreezeTableAge: number | null;
            logAutovacuumMinDuration: number | null;
            userCatalogTable: boolean | null;
          } | null;
          using: string | null;
          definition: string | null;
          withNoData: boolean | null;
          tablespace: string | null;
          materialized: boolean;
        }) | ({
          $diffType: "drop";
          entityType: "schemas";
          name: string;
        } | {
          $diffType: "drop";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled: boolean;
        } | {
          $diffType: "drop";
          entityType: "enums";
          schema: string;
          name: string;
          values: string[];
        } | {
          $diffType: "drop";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          typeSchema: string | null;
          notNull: boolean;
          dimensions: number;
          default: string | null;
          generated: {
            type: "stored";
            as: string;
          } | null;
          identity: {
            name: string;
            type: "always" | "byDefault";
            increment: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cache: number | null;
            cycle: boolean | null;
          } | null;
        } | {
          $diffType: "drop";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          }[];
          with: string;
          nameExplicit: boolean;
          isUnique: boolean;
          where: string | null;
          method: string;
          concurrently: boolean;
        } | {
          $diffType: "drop";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
          onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        } | {
          $diffType: "drop";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "drop";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          nullsNotDistinct: boolean;
        } | {
          $diffType: "drop";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "drop";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cycle: boolean | null;
          incrementBy: string | null;
          cacheSize: number | null;
        } | {
          $diffType: "drop";
          entityType: "roles";
          name: string;
          superuser: boolean | null;
          createDb: boolean | null;
          createRole: boolean | null;
          inherit: boolean | null;
          canLogin: boolean | null;
          replication: boolean | null;
          bypassRls: boolean | null;
          connLimit: number | null;
          password: string | null;
          validUntil: string | null;
        } | {
          $diffType: "drop";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          grantor: string;
          grantee: string;
          isGrantable: boolean;
        } | {
          $diffType: "drop";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as: "PERMISSIVE" | "RESTRICTIVE";
          roles: string[];
          for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          using: string | null;
          withCheck: string | null;
        } | {
          $diffType: "drop";
          entityType: "views";
          schema: string;
          name: string;
          with: {
            checkOption: "local" | "cascaded" | null;
            securityBarrier: boolean | null;
            securityInvoker: boolean | null;
            fillfactor: number | null;
            toastTupleTarget: number | null;
            parallelWorkers: number | null;
            autovacuumEnabled: boolean | null;
            vacuumIndexCleanup: "auto" | "off" | "on" | null;
            vacuumTruncate: boolean | null;
            autovacuumVacuumThreshold: number | null;
            autovacuumVacuumScaleFactor: number | null;
            autovacuumVacuumCostDelay: number | null;
            autovacuumVacuumCostLimit: number | null;
            autovacuumFreezeMinAge: number | null;
            autovacuumFreezeMaxAge: number | null;
            autovacuumFreezeTableAge: number | null;
            autovacuumMultixactFreezeMinAge: number | null;
            autovacuumMultixactFreezeMaxAge: number | null;
            autovacuumMultixactFreezeTableAge: number | null;
            logAutovacuumMinDuration: number | null;
            userCatalogTable: boolean | null;
          } | null;
          using: string | null;
          definition: string | null;
          withNoData: boolean | null;
          tablespace: string | null;
          materialized: boolean;
        });
      };
      all: {
        schemas: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "schemas">;
        tables: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "tables">;
        enums: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "enums">;
        columns: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "columns">;
        indexes: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "indexes">;
        fks: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "fks">;
        pks: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "pks">;
        uniques: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "uniques">;
        checks: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "checks">;
        sequences: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "sequences">;
        roles: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "roles">;
        privileges: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "privileges">;
        policies: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "policies">;
        views: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "views">;
        entities: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "entities">;
      };
    };
    store: {
      collection: Record<string, any>[];
    };
  };
  entities: {
    push: (input: {
      name: string;
      entityType: "schemas";
    } | {
      schema: string;
      isRlsEnabled: boolean;
      name: string;
      entityType: "tables";
    } | {
      schema: string;
      values: string[];
      name: string;
      entityType: "enums";
    } | {
      typeSchema: string | null | undefined;
      default: string | null | undefined;
      generated: {
        type: "stored";
        as: string;
      } | null | undefined;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null | undefined;
      schema: string;
      table: string;
      type: string;
      notNull: boolean;
      dimensions: number;
      name: string;
      entityType: "columns";
    } | {
      where: string | null | undefined;
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      isUnique: boolean;
      with: string;
      method: string;
      concurrently: boolean;
      name: string;
      entityType: "indexes";
    } | {
      onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
      onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      name: string;
      entityType: "fks";
    } | {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      nullsNotDistinct: boolean;
      name: string;
      entityType: "uniques";
    } | {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      incrementBy: string | null | undefined;
      minValue: string | null | undefined;
      maxValue: string | null | undefined;
      startWith: string | null | undefined;
      cacheSize: number | null | undefined;
      cycle: boolean | null | undefined;
      schema: string;
      name: string;
      entityType: "sequences";
    } | {
      superuser: boolean | null | undefined;
      createDb: boolean | null | undefined;
      createRole: boolean | null | undefined;
      inherit: boolean | null | undefined;
      canLogin: boolean | null | undefined;
      replication: boolean | null | undefined;
      bypassRls: boolean | null | undefined;
      connLimit: number | null | undefined;
      password: string | null | undefined;
      validUntil: string | null | undefined;
      name: string;
      entityType: "roles";
    } | {
      grantor: string;
      grantee: string;
      schema: string;
      table: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      isGrantable: boolean;
      name: string;
      entityType: "privileges";
    } | {
      using: string | null | undefined;
      withCheck: string | null | undefined;
      schema: string;
      table: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      roles: string[];
      name: string;
      entityType: "policies";
    } | {
      definition: string | null | undefined;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null | undefined;
      withNoData: boolean | null | undefined;
      using: string | null | undefined;
      tablespace: string | null | undefined;
      schema: string;
      materialized: boolean;
      name: string;
      entityType: "views";
    }, uniques?: "name"[] | ("schema" | "name" | "isRlsEnabled")[] | ("schema" | "name" | "values")[] | ("schema" | "table" | "name" | "type" | "typeSchema" | "notNull" | "dimensions" | "default" | "generated" | "identity")[] | ("schema" | "table" | "name" | "columns" | "with" | "nameExplicit" | "isUnique" | "where" | "method" | "concurrently")[] | ("schema" | "table" | "name" | "columns" | "nameExplicit" | "schemaTo" | "tableTo" | "columnsTo" | "onUpdate" | "onDelete")[] | ("schema" | "table" | "name" | "columns" | "nameExplicit")[] | ("schema" | "table" | "name" | "columns" | "nameExplicit" | "nullsNotDistinct")[] | ("schema" | "table" | "name" | "value")[] | ("schema" | "name" | "minValue" | "maxValue" | "startWith" | "cycle" | "incrementBy" | "cacheSize")[] | ("name" | "superuser" | "createDb" | "createRole" | "inherit" | "canLogin" | "replication" | "bypassRls" | "connLimit" | "password" | "validUntil")[] | ("schema" | "table" | "name" | "type" | "grantor" | "grantee" | "isGrantable")[] | ("schema" | "table" | "name" | "as" | "roles" | "for" | "using" | "withCheck")[] | ("schema" | "name" | "with" | "using" | "definition" | "withNoData" | "tablespace" | "materialized")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        name: string;
        entityType: "schemas";
      } | {
        schema: string;
        isRlsEnabled: boolean;
        name: string;
        entityType: "tables";
      } | {
        schema: string;
        values: string[];
        name: string;
        entityType: "enums";
      } | {
        schema: string;
        table: string;
        type: string;
        typeSchema: string | null;
        notNull: boolean;
        dimensions: number;
        default: string | null;
        generated: {
          type: "stored";
          as: string;
        } | null;
        identity: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        name: string;
        entityType: "columns";
      } | {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        isUnique: boolean;
        where: string | null;
        with: string;
        method: string;
        concurrently: boolean;
        name: string;
        entityType: "indexes";
      } | {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        name: string;
        entityType: "fks";
      } | {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      } | {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        nullsNotDistinct: boolean;
        name: string;
        entityType: "uniques";
      } | {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      } | {
        schema: string;
        incrementBy: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cacheSize: number | null;
        cycle: boolean | null;
        name: string;
        entityType: "sequences";
      } | {
        superuser: boolean | null;
        createDb: boolean | null;
        createRole: boolean | null;
        inherit: boolean | null;
        canLogin: boolean | null;
        replication: boolean | null;
        bypassRls: boolean | null;
        connLimit: number | null;
        password: string | null;
        validUntil: string | null;
        name: string;
        entityType: "roles";
      } | {
        grantor: string;
        grantee: string;
        schema: string;
        table: string;
        type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        isGrantable: boolean;
        name: string;
        entityType: "privileges";
      } | {
        schema: string;
        table: string;
        as: "PERMISSIVE" | "RESTRICTIVE";
        for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        roles: string[];
        using: string | null;
        withCheck: string | null;
        name: string;
        entityType: "policies";
      } | {
        schema: string;
        definition: string | null;
        with: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        withNoData: boolean | null;
        using: string | null;
        tablespace: string | null;
        materialized: boolean;
        name: string;
        entityType: "views";
      };
    };
    list: (where?: ({
      name?: string | undefined;
      entityType?: "schemas" | undefined;
    } | {
      schema?: string | undefined;
      isRlsEnabled?: boolean | undefined;
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | {
      schema?: string | undefined;
      values?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "enums" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      type?: string | undefined;
      typeSchema?: string | null | undefined;
      notNull?: boolean | undefined;
      dimensions?: number | undefined;
      default?: string | null | undefined;
      generated?: {
        type: "stored";
        as: string;
      } | null | undefined;
      identity?: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      with?: string | undefined;
      method?: string | undefined;
      concurrently?: boolean | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      schemaTo?: string | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
      onDelete?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nullsNotDistinct?: boolean | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | {
      schema?: string | undefined;
      incrementBy?: string | null | undefined;
      minValue?: string | null | undefined;
      maxValue?: string | null | undefined;
      startWith?: string | null | undefined;
      cacheSize?: number | null | undefined;
      cycle?: boolean | null | undefined;
      name?: string | undefined;
      entityType?: "sequences" | undefined;
    } | {
      superuser?: boolean | null | undefined;
      createDb?: boolean | null | undefined;
      createRole?: boolean | null | undefined;
      inherit?: boolean | null | undefined;
      canLogin?: boolean | null | undefined;
      replication?: boolean | null | undefined;
      bypassRls?: boolean | null | undefined;
      connLimit?: number | null | undefined;
      password?: string | null | undefined;
      validUntil?: string | null | undefined;
      name?: string | undefined;
      entityType?: "roles" | undefined;
    } | {
      grantor?: string | undefined;
      grantee?: string | undefined;
      schema?: string | undefined;
      table?: string | undefined;
      type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | undefined;
      isGrantable?: boolean | undefined;
      name?: string | undefined;
      entityType?: "privileges" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      as?: "PERMISSIVE" | "RESTRICTIVE" | undefined;
      for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | undefined;
      roles?: string[] | {
        CONTAINS: string;
      } | undefined;
      using?: string | null | undefined;
      withCheck?: string | null | undefined;
      name?: string | undefined;
      entityType?: "policies" | undefined;
    } | {
      schema?: string | undefined;
      definition?: string | null | undefined;
      with?: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null | undefined;
      withNoData?: boolean | null | undefined;
      using?: string | null | undefined;
      tablespace?: string | null | undefined;
      materialized?: boolean | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    }) | undefined) => ({
      name: string;
      entityType: "schemas";
    } | {
      schema: string;
      isRlsEnabled: boolean;
      name: string;
      entityType: "tables";
    } | {
      schema: string;
      values: string[];
      name: string;
      entityType: "enums";
    } | {
      schema: string;
      table: string;
      type: string;
      typeSchema: string | null;
      notNull: boolean;
      dimensions: number;
      default: string | null;
      generated: {
        type: "stored";
        as: string;
      } | null;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      isUnique: boolean;
      where: string | null;
      with: string;
      method: string;
      concurrently: boolean;
      name: string;
      entityType: "indexes";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      name: string;
      entityType: "fks";
    } | {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      nullsNotDistinct: boolean;
      name: string;
      entityType: "uniques";
    } | {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      schema: string;
      incrementBy: string | null;
      minValue: string | null;
      maxValue: string | null;
      startWith: string | null;
      cacheSize: number | null;
      cycle: boolean | null;
      name: string;
      entityType: "sequences";
    } | {
      superuser: boolean | null;
      createDb: boolean | null;
      createRole: boolean | null;
      inherit: boolean | null;
      canLogin: boolean | null;
      replication: boolean | null;
      bypassRls: boolean | null;
      connLimit: number | null;
      password: string | null;
      validUntil: string | null;
      name: string;
      entityType: "roles";
    } | {
      grantor: string;
      grantee: string;
      schema: string;
      table: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      isGrantable: boolean;
      name: string;
      entityType: "privileges";
    } | {
      schema: string;
      table: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      roles: string[];
      using: string | null;
      withCheck: string | null;
      name: string;
      entityType: "policies";
    } | {
      schema: string;
      definition: string | null;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null;
      withNoData: boolean | null;
      using: string | null;
      tablespace: string | null;
      materialized: boolean;
      name: string;
      entityType: "views";
    })[];
    one: (where?: ({
      name?: string | undefined;
      entityType?: "schemas" | undefined;
    } | {
      schema?: string | undefined;
      isRlsEnabled?: boolean | undefined;
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | {
      schema?: string | undefined;
      values?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "enums" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      type?: string | undefined;
      typeSchema?: string | null | undefined;
      notNull?: boolean | undefined;
      dimensions?: number | undefined;
      default?: string | null | undefined;
      generated?: {
        type: "stored";
        as: string;
      } | null | undefined;
      identity?: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      with?: string | undefined;
      method?: string | undefined;
      concurrently?: boolean | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      schemaTo?: string | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
      onDelete?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nullsNotDistinct?: boolean | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | {
      schema?: string | undefined;
      incrementBy?: string | null | undefined;
      minValue?: string | null | undefined;
      maxValue?: string | null | undefined;
      startWith?: string | null | undefined;
      cacheSize?: number | null | undefined;
      cycle?: boolean | null | undefined;
      name?: string | undefined;
      entityType?: "sequences" | undefined;
    } | {
      superuser?: boolean | null | undefined;
      createDb?: boolean | null | undefined;
      createRole?: boolean | null | undefined;
      inherit?: boolean | null | undefined;
      canLogin?: boolean | null | undefined;
      replication?: boolean | null | undefined;
      bypassRls?: boolean | null | undefined;
      connLimit?: number | null | undefined;
      password?: string | null | undefined;
      validUntil?: string | null | undefined;
      name?: string | undefined;
      entityType?: "roles" | undefined;
    } | {
      grantor?: string | undefined;
      grantee?: string | undefined;
      schema?: string | undefined;
      table?: string | undefined;
      type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | undefined;
      isGrantable?: boolean | undefined;
      name?: string | undefined;
      entityType?: "privileges" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      as?: "PERMISSIVE" | "RESTRICTIVE" | undefined;
      for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | undefined;
      roles?: string[] | {
        CONTAINS: string;
      } | undefined;
      using?: string | null | undefined;
      withCheck?: string | null | undefined;
      name?: string | undefined;
      entityType?: "policies" | undefined;
    } | {
      schema?: string | undefined;
      definition?: string | null | undefined;
      with?: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null | undefined;
      withNoData?: boolean | null | undefined;
      using?: string | null | undefined;
      tablespace?: string | null | undefined;
      materialized?: boolean | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    }) | undefined) => {
      name: string;
      entityType: "schemas";
    } | {
      schema: string;
      isRlsEnabled: boolean;
      name: string;
      entityType: "tables";
    } | {
      schema: string;
      values: string[];
      name: string;
      entityType: "enums";
    } | {
      schema: string;
      table: string;
      type: string;
      typeSchema: string | null;
      notNull: boolean;
      dimensions: number;
      default: string | null;
      generated: {
        type: "stored";
        as: string;
      } | null;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      isUnique: boolean;
      where: string | null;
      with: string;
      method: string;
      concurrently: boolean;
      name: string;
      entityType: "indexes";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      name: string;
      entityType: "fks";
    } | {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      nullsNotDistinct: boolean;
      name: string;
      entityType: "uniques";
    } | {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      schema: string;
      incrementBy: string | null;
      minValue: string | null;
      maxValue: string | null;
      startWith: string | null;
      cacheSize: number | null;
      cycle: boolean | null;
      name: string;
      entityType: "sequences";
    } | {
      superuser: boolean | null;
      createDb: boolean | null;
      createRole: boolean | null;
      inherit: boolean | null;
      canLogin: boolean | null;
      replication: boolean | null;
      bypassRls: boolean | null;
      connLimit: number | null;
      password: string | null;
      validUntil: string | null;
      name: string;
      entityType: "roles";
    } | {
      grantor: string;
      grantee: string;
      schema: string;
      table: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      isGrantable: boolean;
      name: string;
      entityType: "privileges";
    } | {
      schema: string;
      table: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      roles: string[];
      using: string | null;
      withCheck: string | null;
      name: string;
      entityType: "policies";
    } | {
      schema: string;
      definition: string | null;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null;
      withNoData: boolean | null;
      using: string | null;
      tablespace: string | null;
      materialized: boolean;
      name: string;
      entityType: "views";
    } | null;
    update: (config: {
      set: {
        name?: string | ((item: string) => string) | undefined;
      };
      where?: {
        name?: string | undefined;
        entityType?: "schemas" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        isRlsEnabled?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        isRlsEnabled?: boolean | undefined;
        name?: string | undefined;
        entityType?: "tables" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        values?: string[] | ((item: string) => string) | undefined;
      };
      where?: {
        schema?: string | undefined;
        values?: string[] | {
          CONTAINS: string;
        } | undefined;
        name?: string | undefined;
        entityType?: "enums" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        type?: string | ((item: string) => string) | undefined;
        typeSchema?: string | ((item: string | null) => string | null) | null | undefined;
        notNull?: boolean | ((item: boolean) => boolean) | undefined;
        dimensions?: number | ((item: number) => number) | undefined;
        default?: string | ((item: string | null) => string | null) | null | undefined;
        generated?: {
          type: "stored";
          as: string;
        } | ((item: {
          type: "stored";
          as: string;
        } | null) => {
          type: "stored";
          as: string;
        } | null) | null | undefined;
        identity?: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | ((item: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null) => {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        type?: string | undefined;
        typeSchema?: string | null | undefined;
        notNull?: boolean | undefined;
        dimensions?: number | undefined;
        default?: string | null | undefined;
        generated?: {
          type: "stored";
          as: string;
        } | null | undefined;
        identity?: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null | undefined;
        name?: string | undefined;
        entityType?: "columns" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[] | ((item: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }) => {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }) | undefined;
        with?: string | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        isUnique?: boolean | ((item: boolean) => boolean) | undefined;
        where?: string | ((item: string | null) => string | null) | null | undefined;
        method?: string | ((item: string) => string) | undefined;
        concurrently?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        nameExplicit?: boolean | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[] | {
          CONTAINS: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          };
        } | undefined;
        isUnique?: boolean | undefined;
        where?: string | null | undefined;
        with?: string | undefined;
        method?: string | undefined;
        concurrently?: boolean | undefined;
        name?: string | undefined;
        entityType?: "indexes" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        schemaTo?: string | ((item: string) => string) | undefined;
        tableTo?: string | ((item: string) => string) | undefined;
        columnsTo?: string[] | ((item: string) => string) | undefined;
        onUpdate?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | ((item: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null) => "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null) | null | undefined;
        onDelete?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | ((item: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null) => "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        nameExplicit?: boolean | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        schemaTo?: string | undefined;
        tableTo?: string | undefined;
        columnsTo?: string[] | {
          CONTAINS: string;
        } | undefined;
        onUpdate?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
        onDelete?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
        name?: string | undefined;
        entityType?: "fks" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        nameExplicit?: boolean | undefined;
        name?: string | undefined;
        entityType?: "pks" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        nullsNotDistinct?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        nameExplicit?: boolean | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        nullsNotDistinct?: boolean | undefined;
        name?: string | undefined;
        entityType?: "uniques" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        value?: string | ((item: string) => string) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        value?: string | undefined;
        name?: string | undefined;
        entityType?: "checks" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        minValue?: string | ((item: string | null) => string | null) | null | undefined;
        maxValue?: string | ((item: string | null) => string | null) | null | undefined;
        startWith?: string | ((item: string | null) => string | null) | null | undefined;
        cycle?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        incrementBy?: string | ((item: string | null) => string | null) | null | undefined;
        cacheSize?: number | ((item: number | null) => number | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        incrementBy?: string | null | undefined;
        minValue?: string | null | undefined;
        maxValue?: string | null | undefined;
        startWith?: string | null | undefined;
        cacheSize?: number | null | undefined;
        cycle?: boolean | null | undefined;
        name?: string | undefined;
        entityType?: "sequences" | undefined;
      } | undefined;
    } | {
      set: {
        name?: string | ((item: string) => string) | undefined;
        superuser?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        createDb?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        createRole?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        inherit?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        canLogin?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        replication?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        bypassRls?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        connLimit?: number | ((item: number | null) => number | null) | null | undefined;
        password?: string | ((item: string | null) => string | null) | null | undefined;
        validUntil?: string | ((item: string | null) => string | null) | null | undefined;
      };
      where?: {
        superuser?: boolean | null | undefined;
        createDb?: boolean | null | undefined;
        createRole?: boolean | null | undefined;
        inherit?: boolean | null | undefined;
        canLogin?: boolean | null | undefined;
        replication?: boolean | null | undefined;
        bypassRls?: boolean | null | undefined;
        connLimit?: number | null | undefined;
        password?: string | null | undefined;
        validUntil?: string | null | undefined;
        name?: string | undefined;
        entityType?: "roles" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | ((item: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER") => "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER") | undefined;
        grantor?: string | ((item: string) => string) | undefined;
        grantee?: string | ((item: string) => string) | undefined;
        isGrantable?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        grantor?: string | undefined;
        grantee?: string | undefined;
        schema?: string | undefined;
        table?: string | undefined;
        type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | undefined;
        isGrantable?: boolean | undefined;
        name?: string | undefined;
        entityType?: "privileges" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        as?: "PERMISSIVE" | "RESTRICTIVE" | ((item: "PERMISSIVE" | "RESTRICTIVE") => "PERMISSIVE" | "RESTRICTIVE") | undefined;
        roles?: string[] | ((item: string) => string) | undefined;
        for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | ((item: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE") => "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE") | undefined;
        using?: string | ((item: string | null) => string | null) | null | undefined;
        withCheck?: string | ((item: string | null) => string | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        as?: "PERMISSIVE" | "RESTRICTIVE" | undefined;
        for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | undefined;
        roles?: string[] | {
          CONTAINS: string;
        } | undefined;
        using?: string | null | undefined;
        withCheck?: string | null | undefined;
        name?: string | undefined;
        entityType?: "policies" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        with?: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | ((item: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null) => {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null) | null | undefined;
        using?: string | ((item: string | null) => string | null) | null | undefined;
        definition?: string | ((item: string | null) => string | null) | null | undefined;
        withNoData?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        tablespace?: string | ((item: string | null) => string | null) | null | undefined;
        materialized?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        definition?: string | null | undefined;
        with?: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null | undefined;
        withNoData?: boolean | null | undefined;
        using?: string | null | undefined;
        tablespace?: string | null | undefined;
        materialized?: boolean | undefined;
        name?: string | undefined;
        entityType?: "views" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: ({
        name: string;
        entityType: "schemas";
      } | {
        schema: string;
        isRlsEnabled: boolean;
        name: string;
        entityType: "tables";
      } | {
        schema: string;
        values: string[];
        name: string;
        entityType: "enums";
      } | {
        schema: string;
        table: string;
        type: string;
        typeSchema: string | null;
        notNull: boolean;
        dimensions: number;
        default: string | null;
        generated: {
          type: "stored";
          as: string;
        } | null;
        identity: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        name: string;
        entityType: "columns";
      } | {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        isUnique: boolean;
        where: string | null;
        with: string;
        method: string;
        concurrently: boolean;
        name: string;
        entityType: "indexes";
      } | {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        name: string;
        entityType: "fks";
      } | {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      } | {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        nullsNotDistinct: boolean;
        name: string;
        entityType: "uniques";
      } | {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      } | {
        schema: string;
        incrementBy: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cacheSize: number | null;
        cycle: boolean | null;
        name: string;
        entityType: "sequences";
      } | {
        superuser: boolean | null;
        createDb: boolean | null;
        createRole: boolean | null;
        inherit: boolean | null;
        canLogin: boolean | null;
        replication: boolean | null;
        bypassRls: boolean | null;
        connLimit: number | null;
        password: string | null;
        validUntil: string | null;
        name: string;
        entityType: "roles";
      } | {
        grantor: string;
        grantee: string;
        schema: string;
        table: string;
        type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        isGrantable: boolean;
        name: string;
        entityType: "privileges";
      } | {
        schema: string;
        table: string;
        as: "PERMISSIVE" | "RESTRICTIVE";
        for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        roles: string[];
        using: string | null;
        withCheck: string | null;
        name: string;
        entityType: "policies";
      } | {
        schema: string;
        definition: string | null;
        with: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        withNoData: boolean | null;
        using: string | null;
        tablespace: string | null;
        materialized: boolean;
        name: string;
        entityType: "views";
      })[];
    };
    delete: (where?: {
      name?: string | undefined;
      entityType?: "schemas" | undefined;
    } | {
      schema?: string | undefined;
      isRlsEnabled?: boolean | undefined;
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | {
      schema?: string | undefined;
      values?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "enums" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      type?: string | undefined;
      typeSchema?: string | null | undefined;
      notNull?: boolean | undefined;
      dimensions?: number | undefined;
      default?: string | null | undefined;
      generated?: {
        type: "stored";
        as: string;
      } | null | undefined;
      identity?: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      with?: string | undefined;
      method?: string | undefined;
      concurrently?: boolean | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      schemaTo?: string | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
      onDelete?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nullsNotDistinct?: boolean | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | {
      schema?: string | undefined;
      incrementBy?: string | null | undefined;
      minValue?: string | null | undefined;
      maxValue?: string | null | undefined;
      startWith?: string | null | undefined;
      cacheSize?: number | null | undefined;
      cycle?: boolean | null | undefined;
      name?: string | undefined;
      entityType?: "sequences" | undefined;
    } | {
      superuser?: boolean | null | undefined;
      createDb?: boolean | null | undefined;
      createRole?: boolean | null | undefined;
      inherit?: boolean | null | undefined;
      canLogin?: boolean | null | undefined;
      replication?: boolean | null | undefined;
      bypassRls?: boolean | null | undefined;
      connLimit?: number | null | undefined;
      password?: string | null | undefined;
      validUntil?: string | null | undefined;
      name?: string | undefined;
      entityType?: "roles" | undefined;
    } | {
      grantor?: string | undefined;
      grantee?: string | undefined;
      schema?: string | undefined;
      table?: string | undefined;
      type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | undefined;
      isGrantable?: boolean | undefined;
      name?: string | undefined;
      entityType?: "privileges" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      as?: "PERMISSIVE" | "RESTRICTIVE" | undefined;
      for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | undefined;
      roles?: string[] | {
        CONTAINS: string;
      } | undefined;
      using?: string | null | undefined;
      withCheck?: string | null | undefined;
      name?: string | undefined;
      entityType?: "policies" | undefined;
    } | {
      schema?: string | undefined;
      definition?: string | null | undefined;
      with?: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null | undefined;
      withNoData?: boolean | null | undefined;
      using?: string | null | undefined;
      tablespace?: string | null | undefined;
      materialized?: boolean | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | undefined) => ({
      name: string;
      entityType: "schemas";
    } | {
      schema: string;
      isRlsEnabled: boolean;
      name: string;
      entityType: "tables";
    } | {
      schema: string;
      values: string[];
      name: string;
      entityType: "enums";
    } | {
      schema: string;
      table: string;
      type: string;
      typeSchema: string | null;
      notNull: boolean;
      dimensions: number;
      default: string | null;
      generated: {
        type: "stored";
        as: string;
      } | null;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      isUnique: boolean;
      where: string | null;
      with: string;
      method: string;
      concurrently: boolean;
      name: string;
      entityType: "indexes";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      name: string;
      entityType: "fks";
    } | {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      nullsNotDistinct: boolean;
      name: string;
      entityType: "uniques";
    } | {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      schema: string;
      incrementBy: string | null;
      minValue: string | null;
      maxValue: string | null;
      startWith: string | null;
      cacheSize: number | null;
      cycle: boolean | null;
      name: string;
      entityType: "sequences";
    } | {
      superuser: boolean | null;
      createDb: boolean | null;
      createRole: boolean | null;
      inherit: boolean | null;
      canLogin: boolean | null;
      replication: boolean | null;
      bypassRls: boolean | null;
      connLimit: number | null;
      password: string | null;
      validUntil: string | null;
      name: string;
      entityType: "roles";
    } | {
      grantor: string;
      grantee: string;
      schema: string;
      table: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      isGrantable: boolean;
      name: string;
      entityType: "privileges";
    } | {
      schema: string;
      table: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      roles: string[];
      using: string | null;
      withCheck: string | null;
      name: string;
      entityType: "policies";
    } | {
      schema: string;
      definition: string | null;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null;
      withNoData: boolean | null;
      using: string | null;
      tablespace: string | null;
      materialized: boolean;
      name: string;
      entityType: "views";
    })[];
    validate: (data: unknown) => data is {
      name: string;
      entityType: "schemas";
    } | {
      schema: string;
      isRlsEnabled: boolean;
      name: string;
      entityType: "tables";
    } | {
      schema: string;
      values: string[];
      name: string;
      entityType: "enums";
    } | {
      schema: string;
      table: string;
      type: string;
      typeSchema: string | null;
      notNull: boolean;
      dimensions: number;
      default: string | null;
      generated: {
        type: "stored";
        as: string;
      } | null;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      isUnique: boolean;
      where: string | null;
      with: string;
      method: string;
      concurrently: boolean;
      name: string;
      entityType: "indexes";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      name: string;
      entityType: "fks";
    } | {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      nullsNotDistinct: boolean;
      name: string;
      entityType: "uniques";
    } | {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      schema: string;
      incrementBy: string | null;
      minValue: string | null;
      maxValue: string | null;
      startWith: string | null;
      cacheSize: number | null;
      cycle: boolean | null;
      name: string;
      entityType: "sequences";
    } | {
      superuser: boolean | null;
      createDb: boolean | null;
      createRole: boolean | null;
      inherit: boolean | null;
      canLogin: boolean | null;
      replication: boolean | null;
      bypassRls: boolean | null;
      connLimit: number | null;
      password: string | null;
      validUntil: string | null;
      name: string;
      entityType: "roles";
    } | {
      grantor: string;
      grantee: string;
      schema: string;
      table: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      isGrantable: boolean;
      name: string;
      entityType: "privileges";
    } | {
      schema: string;
      table: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      roles: string[];
      using: string | null;
      withCheck: string | null;
      name: string;
      entityType: "policies";
    } | {
      schema: string;
      definition: string | null;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null;
      withNoData: boolean | null;
      using: string | null;
      tablespace: string | null;
      materialized: boolean;
      name: string;
      entityType: "views";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "schemas";
      name: string;
      $left: {
        name: string;
        entityType: "schemas";
      };
      $right: {
        name: string;
        entityType: "schemas";
      };
    } | {
      $diffType: "alter";
      entityType: "tables";
      schema: string;
      name: string;
      isRlsEnabled?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        isRlsEnabled: boolean;
        name: string;
        entityType: "tables";
      };
      $right: {
        schema: string;
        isRlsEnabled: boolean;
        name: string;
        entityType: "tables";
      };
    } | {
      $diffType: "alter";
      entityType: "enums";
      schema: string;
      name: string;
      values?: {
        from: string[];
        to: string[];
      } | undefined;
      $left: {
        schema: string;
        values: string[];
        name: string;
        entityType: "enums";
      };
      $right: {
        schema: string;
        values: string[];
        name: string;
        entityType: "enums";
      };
    } | {
      $diffType: "alter";
      entityType: "columns";
      schema: string;
      table: string;
      name: string;
      type?: {
        from: string;
        to: string;
      } | undefined;
      typeSchema?: {
        from: string | null;
        to: string | null;
      } | undefined;
      notNull?: {
        from: boolean;
        to: boolean;
      } | undefined;
      dimensions?: {
        from: number;
        to: number;
      } | undefined;
      default?: {
        from: string | null;
        to: string | null;
      } | undefined;
      generated?: {
        from: {
          type: "stored";
          as: string;
        } | null;
        to: {
          type: "stored";
          as: string;
        } | null;
      } | undefined;
      identity?: {
        from: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        to: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        type: string;
        typeSchema: string | null;
        notNull: boolean;
        dimensions: number;
        default: string | null;
        generated: {
          type: "stored";
          as: string;
        } | null;
        identity: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        name: string;
        entityType: "columns";
      };
      $right: {
        schema: string;
        table: string;
        type: string;
        typeSchema: string | null;
        notNull: boolean;
        dimensions: number;
        default: string | null;
        generated: {
          type: "stored";
          as: string;
        } | null;
        identity: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        name: string;
        entityType: "columns";
      };
    } | {
      $diffType: "alter";
      entityType: "indexes";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        to: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
      } | undefined;
      with?: {
        from: string;
        to: string;
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      isUnique?: {
        from: boolean;
        to: boolean;
      } | undefined;
      where?: {
        from: string | null;
        to: string | null;
      } | undefined;
      method?: {
        from: string;
        to: string;
      } | undefined;
      concurrently?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        isUnique: boolean;
        where: string | null;
        with: string;
        method: string;
        concurrently: boolean;
        name: string;
        entityType: "indexes";
      };
      $right: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        isUnique: boolean;
        where: string | null;
        with: string;
        method: string;
        concurrently: boolean;
        name: string;
        entityType: "indexes";
      };
    } | {
      $diffType: "alter";
      entityType: "fks";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      schemaTo?: {
        from: string;
        to: string;
      } | undefined;
      tableTo?: {
        from: string;
        to: string;
      } | undefined;
      columnsTo?: {
        from: string[];
        to: string[];
      } | undefined;
      onUpdate?: {
        from: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        to: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      } | undefined;
      onDelete?: {
        from: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        to: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        name: string;
        entityType: "fks";
      };
      $right: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        name: string;
        entityType: "fks";
      };
    } | {
      $diffType: "alter";
      entityType: "pks";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      };
      $right: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      };
    } | {
      $diffType: "alter";
      entityType: "uniques";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      nullsNotDistinct?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        nullsNotDistinct: boolean;
        name: string;
        entityType: "uniques";
      };
      $right: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        nullsNotDistinct: boolean;
        name: string;
        entityType: "uniques";
      };
    } | {
      $diffType: "alter";
      entityType: "checks";
      schema: string;
      table: string;
      name: string;
      value?: {
        from: string;
        to: string;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
      $right: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
    } | {
      $diffType: "alter";
      entityType: "sequences";
      schema: string;
      name: string;
      minValue?: {
        from: string | null;
        to: string | null;
      } | undefined;
      maxValue?: {
        from: string | null;
        to: string | null;
      } | undefined;
      startWith?: {
        from: string | null;
        to: string | null;
      } | undefined;
      cycle?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      incrementBy?: {
        from: string | null;
        to: string | null;
      } | undefined;
      cacheSize?: {
        from: number | null;
        to: number | null;
      } | undefined;
      $left: {
        schema: string;
        incrementBy: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cacheSize: number | null;
        cycle: boolean | null;
        name: string;
        entityType: "sequences";
      };
      $right: {
        schema: string;
        incrementBy: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cacheSize: number | null;
        cycle: boolean | null;
        name: string;
        entityType: "sequences";
      };
    } | {
      $diffType: "alter";
      entityType: "roles";
      name: string;
      superuser?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      createDb?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      createRole?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      inherit?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      canLogin?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      replication?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      bypassRls?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      connLimit?: {
        from: number | null;
        to: number | null;
      } | undefined;
      password?: {
        from: string | null;
        to: string | null;
      } | undefined;
      validUntil?: {
        from: string | null;
        to: string | null;
      } | undefined;
      $left: {
        superuser: boolean | null;
        createDb: boolean | null;
        createRole: boolean | null;
        inherit: boolean | null;
        canLogin: boolean | null;
        replication: boolean | null;
        bypassRls: boolean | null;
        connLimit: number | null;
        password: string | null;
        validUntil: string | null;
        name: string;
        entityType: "roles";
      };
      $right: {
        superuser: boolean | null;
        createDb: boolean | null;
        createRole: boolean | null;
        inherit: boolean | null;
        canLogin: boolean | null;
        replication: boolean | null;
        bypassRls: boolean | null;
        connLimit: number | null;
        password: string | null;
        validUntil: string | null;
        name: string;
        entityType: "roles";
      };
    } | {
      $diffType: "alter";
      entityType: "privileges";
      schema: string;
      table: string;
      name: string;
      type?: {
        from: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        to: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      } | undefined;
      grantor?: {
        from: string;
        to: string;
      } | undefined;
      grantee?: {
        from: string;
        to: string;
      } | undefined;
      isGrantable?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        grantor: string;
        grantee: string;
        schema: string;
        table: string;
        type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        isGrantable: boolean;
        name: string;
        entityType: "privileges";
      };
      $right: {
        grantor: string;
        grantee: string;
        schema: string;
        table: string;
        type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        isGrantable: boolean;
        name: string;
        entityType: "privileges";
      };
    } | {
      $diffType: "alter";
      entityType: "policies";
      schema: string;
      table: string;
      name: string;
      as?: {
        from: "PERMISSIVE" | "RESTRICTIVE";
        to: "PERMISSIVE" | "RESTRICTIVE";
      } | undefined;
      roles?: {
        from: string[];
        to: string[];
      } | undefined;
      for?: {
        from: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        to: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      } | undefined;
      using?: {
        from: string | null;
        to: string | null;
      } | undefined;
      withCheck?: {
        from: string | null;
        to: string | null;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        as: "PERMISSIVE" | "RESTRICTIVE";
        for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        roles: string[];
        using: string | null;
        withCheck: string | null;
        name: string;
        entityType: "policies";
      };
      $right: {
        schema: string;
        table: string;
        as: "PERMISSIVE" | "RESTRICTIVE";
        for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        roles: string[];
        using: string | null;
        withCheck: string | null;
        name: string;
        entityType: "policies";
      };
    } | {
      $diffType: "alter";
      entityType: "views";
      schema: string;
      name: string;
      with?: {
        from: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        to: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
      } | undefined;
      using?: {
        from: string | null;
        to: string | null;
      } | undefined;
      definition?: {
        from: string | null;
        to: string | null;
      } | undefined;
      withNoData?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      tablespace?: {
        from: string | null;
        to: string | null;
      } | undefined;
      materialized?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        definition: string | null;
        with: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        withNoData: boolean | null;
        using: string | null;
        tablespace: string | null;
        materialized: boolean;
        name: string;
        entityType: "views";
      };
      $right: {
        schema: string;
        definition: string | null;
        with: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        withNoData: boolean | null;
        using: string | null;
        tablespace: string | null;
        materialized: boolean;
        name: string;
        entityType: "views";
      };
    }) => boolean;
  };
  schemas: {
    push: (input: {
      name: string;
    }, uniques?: "name"[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        name: string;
        entityType: "schemas";
      };
    };
    list: (where?: {
      name?: string | undefined;
      entityType?: "schemas" | undefined;
    } | undefined) => {
      name: string;
      entityType: "schemas";
    }[];
    one: (where?: {
      name?: string | undefined;
      entityType?: "schemas" | undefined;
    } | undefined) => {
      name: string;
      entityType: "schemas";
    } | null;
    update: (config: {
      set: {
        name?: string | ((item: string) => string) | undefined;
      };
      where?: {
        name?: string | undefined;
        entityType?: "schemas" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        name: string;
        entityType: "schemas";
      }[];
    };
    delete: (where?: {
      name?: string | undefined;
      entityType?: "schemas" | undefined;
    } | undefined) => {
      name: string;
      entityType: "schemas";
    }[];
    validate: (data: unknown) => data is {
      name: string;
      entityType: "schemas";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "schemas";
      name: string;
      $left: {
        name: string;
        entityType: "schemas";
      };
      $right: {
        name: string;
        entityType: "schemas";
      };
    }) => boolean;
  };
  tables: {
    push: (input: {
      schema: string;
      name: string;
      isRlsEnabled: boolean;
    }, uniques?: ("schema" | "name" | "isRlsEnabled")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        isRlsEnabled: boolean;
        name: string;
        entityType: "tables";
      };
    };
    list: (where?: {
      schema?: string | undefined;
      isRlsEnabled?: boolean | undefined;
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | undefined) => {
      schema: string;
      isRlsEnabled: boolean;
      name: string;
      entityType: "tables";
    }[];
    one: (where?: {
      schema?: string | undefined;
      isRlsEnabled?: boolean | undefined;
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | undefined) => {
      schema: string;
      isRlsEnabled: boolean;
      name: string;
      entityType: "tables";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        isRlsEnabled?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        isRlsEnabled?: boolean | undefined;
        name?: string | undefined;
        entityType?: "tables" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        isRlsEnabled: boolean;
        name: string;
        entityType: "tables";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      isRlsEnabled?: boolean | undefined;
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | undefined) => {
      schema: string;
      isRlsEnabled: boolean;
      name: string;
      entityType: "tables";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      isRlsEnabled: boolean;
      name: string;
      entityType: "tables";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "tables";
      schema: string;
      name: string;
      isRlsEnabled?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        isRlsEnabled: boolean;
        name: string;
        entityType: "tables";
      };
      $right: {
        schema: string;
        isRlsEnabled: boolean;
        name: string;
        entityType: "tables";
      };
    }) => boolean;
  };
  enums: {
    push: (input: {
      schema: string;
      name: string;
      values: string[];
    }, uniques?: ("schema" | "name" | "values")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        values: string[];
        name: string;
        entityType: "enums";
      };
    };
    list: (where?: {
      schema?: string | undefined;
      values?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "enums" | undefined;
    } | undefined) => {
      schema: string;
      values: string[];
      name: string;
      entityType: "enums";
    }[];
    one: (where?: {
      schema?: string | undefined;
      values?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "enums" | undefined;
    } | undefined) => {
      schema: string;
      values: string[];
      name: string;
      entityType: "enums";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        values?: string[] | ((item: string) => string) | undefined;
      };
      where?: {
        schema?: string | undefined;
        values?: string[] | {
          CONTAINS: string;
        } | undefined;
        name?: string | undefined;
        entityType?: "enums" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        values: string[];
        name: string;
        entityType: "enums";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      values?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "enums" | undefined;
    } | undefined) => {
      schema: string;
      values: string[];
      name: string;
      entityType: "enums";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      values: string[];
      name: string;
      entityType: "enums";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "enums";
      schema: string;
      name: string;
      values?: {
        from: string[];
        to: string[];
      } | undefined;
      $left: {
        schema: string;
        values: string[];
        name: string;
        entityType: "enums";
      };
      $right: {
        schema: string;
        values: string[];
        name: string;
        entityType: "enums";
      };
    }) => boolean;
  };
  columns: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      type: string;
      typeSchema: string | null | undefined;
      notNull: boolean;
      dimensions: number;
      default: string | null | undefined;
      generated: {
        type: "stored";
        as: string;
      } | null | undefined;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null | undefined;
    }, uniques?: ("schema" | "table" | "name" | "type" | "typeSchema" | "notNull" | "dimensions" | "default" | "generated" | "identity")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        type: string;
        typeSchema: string | null;
        notNull: boolean;
        dimensions: number;
        default: string | null;
        generated: {
          type: "stored";
          as: string;
        } | null;
        identity: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        name: string;
        entityType: "columns";
      };
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      type?: string | undefined;
      typeSchema?: string | null | undefined;
      notNull?: boolean | undefined;
      dimensions?: number | undefined;
      default?: string | null | undefined;
      generated?: {
        type: "stored";
        as: string;
      } | null | undefined;
      identity?: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      type: string;
      typeSchema: string | null;
      notNull: boolean;
      dimensions: number;
      default: string | null;
      generated: {
        type: "stored";
        as: string;
      } | null;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null;
      name: string;
      entityType: "columns";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      type?: string | undefined;
      typeSchema?: string | null | undefined;
      notNull?: boolean | undefined;
      dimensions?: number | undefined;
      default?: string | null | undefined;
      generated?: {
        type: "stored";
        as: string;
      } | null | undefined;
      identity?: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      type: string;
      typeSchema: string | null;
      notNull: boolean;
      dimensions: number;
      default: string | null;
      generated: {
        type: "stored";
        as: string;
      } | null;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null;
      name: string;
      entityType: "columns";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        type?: string | ((item: string) => string) | undefined;
        typeSchema?: string | ((item: string | null) => string | null) | null | undefined;
        notNull?: boolean | ((item: boolean) => boolean) | undefined;
        dimensions?: number | ((item: number) => number) | undefined;
        default?: string | ((item: string | null) => string | null) | null | undefined;
        generated?: {
          type: "stored";
          as: string;
        } | ((item: {
          type: "stored";
          as: string;
        } | null) => {
          type: "stored";
          as: string;
        } | null) | null | undefined;
        identity?: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | ((item: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null) => {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        type?: string | undefined;
        typeSchema?: string | null | undefined;
        notNull?: boolean | undefined;
        dimensions?: number | undefined;
        default?: string | null | undefined;
        generated?: {
          type: "stored";
          as: string;
        } | null | undefined;
        identity?: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null | undefined;
        name?: string | undefined;
        entityType?: "columns" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        type: string;
        typeSchema: string | null;
        notNull: boolean;
        dimensions: number;
        default: string | null;
        generated: {
          type: "stored";
          as: string;
        } | null;
        identity: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        name: string;
        entityType: "columns";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      type?: string | undefined;
      typeSchema?: string | null | undefined;
      notNull?: boolean | undefined;
      dimensions?: number | undefined;
      default?: string | null | undefined;
      generated?: {
        type: "stored";
        as: string;
      } | null | undefined;
      identity?: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      type: string;
      typeSchema: string | null;
      notNull: boolean;
      dimensions: number;
      default: string | null;
      generated: {
        type: "stored";
        as: string;
      } | null;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null;
      name: string;
      entityType: "columns";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      type: string;
      typeSchema: string | null;
      notNull: boolean;
      dimensions: number;
      default: string | null;
      generated: {
        type: "stored";
        as: string;
      } | null;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null;
      name: string;
      entityType: "columns";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "columns";
      schema: string;
      table: string;
      name: string;
      type?: {
        from: string;
        to: string;
      } | undefined;
      typeSchema?: {
        from: string | null;
        to: string | null;
      } | undefined;
      notNull?: {
        from: boolean;
        to: boolean;
      } | undefined;
      dimensions?: {
        from: number;
        to: number;
      } | undefined;
      default?: {
        from: string | null;
        to: string | null;
      } | undefined;
      generated?: {
        from: {
          type: "stored";
          as: string;
        } | null;
        to: {
          type: "stored";
          as: string;
        } | null;
      } | undefined;
      identity?: {
        from: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        to: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        type: string;
        typeSchema: string | null;
        notNull: boolean;
        dimensions: number;
        default: string | null;
        generated: {
          type: "stored";
          as: string;
        } | null;
        identity: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        name: string;
        entityType: "columns";
      };
      $right: {
        schema: string;
        table: string;
        type: string;
        typeSchema: string | null;
        notNull: boolean;
        dimensions: number;
        default: string | null;
        generated: {
          type: "stored";
          as: string;
        } | null;
        identity: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        name: string;
        entityType: "columns";
      };
    }) => boolean;
  };
  indexes: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      with: string;
      nameExplicit: boolean;
      isUnique: boolean;
      where: string | null | undefined;
      method: string;
      concurrently: boolean;
    }, uniques?: ("schema" | "table" | "name" | "columns" | "with" | "nameExplicit" | "isUnique" | "where" | "method" | "concurrently")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        isUnique: boolean;
        where: string | null;
        with: string;
        method: string;
        concurrently: boolean;
        name: string;
        entityType: "indexes";
      };
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      with?: string | undefined;
      method?: string | undefined;
      concurrently?: boolean | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      isUnique: boolean;
      where: string | null;
      with: string;
      method: string;
      concurrently: boolean;
      name: string;
      entityType: "indexes";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      with?: string | undefined;
      method?: string | undefined;
      concurrently?: boolean | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      isUnique: boolean;
      where: string | null;
      with: string;
      method: string;
      concurrently: boolean;
      name: string;
      entityType: "indexes";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[] | ((item: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }) => {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }) | undefined;
        with?: string | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        isUnique?: boolean | ((item: boolean) => boolean) | undefined;
        where?: string | ((item: string | null) => string | null) | null | undefined;
        method?: string | ((item: string) => string) | undefined;
        concurrently?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        nameExplicit?: boolean | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[] | {
          CONTAINS: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          };
        } | undefined;
        isUnique?: boolean | undefined;
        where?: string | null | undefined;
        with?: string | undefined;
        method?: string | undefined;
        concurrently?: boolean | undefined;
        name?: string | undefined;
        entityType?: "indexes" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        isUnique: boolean;
        where: string | null;
        with: string;
        method: string;
        concurrently: boolean;
        name: string;
        entityType: "indexes";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      with?: string | undefined;
      method?: string | undefined;
      concurrently?: boolean | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      isUnique: boolean;
      where: string | null;
      with: string;
      method: string;
      concurrently: boolean;
      name: string;
      entityType: "indexes";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      isUnique: boolean;
      where: string | null;
      with: string;
      method: string;
      concurrently: boolean;
      name: string;
      entityType: "indexes";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "indexes";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        to: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
      } | undefined;
      with?: {
        from: string;
        to: string;
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      isUnique?: {
        from: boolean;
        to: boolean;
      } | undefined;
      where?: {
        from: string | null;
        to: string | null;
      } | undefined;
      method?: {
        from: string;
        to: string;
      } | undefined;
      concurrently?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        isUnique: boolean;
        where: string | null;
        with: string;
        method: string;
        concurrently: boolean;
        name: string;
        entityType: "indexes";
      };
      $right: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        isUnique: boolean;
        where: string | null;
        with: string;
        method: string;
        concurrently: boolean;
        name: string;
        entityType: "indexes";
      };
    }) => boolean;
  };
  fks: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      columns: string[];
      nameExplicit: boolean;
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
      onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
    }, uniques?: ("schema" | "table" | "name" | "columns" | "nameExplicit" | "schemaTo" | "tableTo" | "columnsTo" | "onUpdate" | "onDelete")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        name: string;
        entityType: "fks";
      };
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      schemaTo?: string | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
      onDelete?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      name: string;
      entityType: "fks";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      schemaTo?: string | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
      onDelete?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      name: string;
      entityType: "fks";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        schemaTo?: string | ((item: string) => string) | undefined;
        tableTo?: string | ((item: string) => string) | undefined;
        columnsTo?: string[] | ((item: string) => string) | undefined;
        onUpdate?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | ((item: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null) => "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null) | null | undefined;
        onDelete?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | ((item: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null) => "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        nameExplicit?: boolean | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        schemaTo?: string | undefined;
        tableTo?: string | undefined;
        columnsTo?: string[] | {
          CONTAINS: string;
        } | undefined;
        onUpdate?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
        onDelete?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
        name?: string | undefined;
        entityType?: "fks" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        name: string;
        entityType: "fks";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      schemaTo?: string | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
      onDelete?: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      name: string;
      entityType: "fks";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      name: string;
      entityType: "fks";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "fks";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      schemaTo?: {
        from: string;
        to: string;
      } | undefined;
      tableTo?: {
        from: string;
        to: string;
      } | undefined;
      columnsTo?: {
        from: string[];
        to: string[];
      } | undefined;
      onUpdate?: {
        from: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        to: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      } | undefined;
      onDelete?: {
        from: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        to: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        name: string;
        entityType: "fks";
      };
      $right: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        onDelete: "NO ACTION" | "RESTRICT" | "SET NULL" | "CASCADE" | "SET DEFAULT" | null;
        name: string;
        entityType: "fks";
      };
    }) => boolean;
  };
  pks: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      columns: string[];
      nameExplicit: boolean;
    }, uniques?: ("schema" | "table" | "name" | "columns" | "nameExplicit")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      };
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        nameExplicit?: boolean | undefined;
        name?: string | undefined;
        entityType?: "pks" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "pks";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      };
      $right: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      };
    }) => boolean;
  };
  uniques: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      columns: string[];
      nameExplicit: boolean;
      nullsNotDistinct: boolean;
    }, uniques?: ("schema" | "table" | "name" | "columns" | "nameExplicit" | "nullsNotDistinct")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        nullsNotDistinct: boolean;
        name: string;
        entityType: "uniques";
      };
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nullsNotDistinct?: boolean | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      nullsNotDistinct: boolean;
      name: string;
      entityType: "uniques";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nullsNotDistinct?: boolean | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      nullsNotDistinct: boolean;
      name: string;
      entityType: "uniques";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        nullsNotDistinct?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        nameExplicit?: boolean | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        nullsNotDistinct?: boolean | undefined;
        name?: string | undefined;
        entityType?: "uniques" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        nullsNotDistinct: boolean;
        name: string;
        entityType: "uniques";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nullsNotDistinct?: boolean | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      nullsNotDistinct: boolean;
      name: string;
      entityType: "uniques";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      nullsNotDistinct: boolean;
      name: string;
      entityType: "uniques";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "uniques";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      nullsNotDistinct?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        nullsNotDistinct: boolean;
        name: string;
        entityType: "uniques";
      };
      $right: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        nullsNotDistinct: boolean;
        name: string;
        entityType: "uniques";
      };
    }) => boolean;
  };
  checks: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      value: string;
    }, uniques?: ("schema" | "table" | "name" | "value")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        value?: string | ((item: string) => string) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        value?: string | undefined;
        name?: string | undefined;
        entityType?: "checks" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "checks";
      schema: string;
      table: string;
      name: string;
      value?: {
        from: string;
        to: string;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
      $right: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
    }) => boolean;
  };
  sequences: {
    push: (input: {
      schema: string;
      name: string;
      minValue: string | null | undefined;
      maxValue: string | null | undefined;
      startWith: string | null | undefined;
      cycle: boolean | null | undefined;
      incrementBy: string | null | undefined;
      cacheSize: number | null | undefined;
    }, uniques?: ("schema" | "name" | "minValue" | "maxValue" | "startWith" | "cycle" | "incrementBy" | "cacheSize")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        incrementBy: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cacheSize: number | null;
        cycle: boolean | null;
        name: string;
        entityType: "sequences";
      };
    };
    list: (where?: {
      schema?: string | undefined;
      incrementBy?: string | null | undefined;
      minValue?: string | null | undefined;
      maxValue?: string | null | undefined;
      startWith?: string | null | undefined;
      cacheSize?: number | null | undefined;
      cycle?: boolean | null | undefined;
      name?: string | undefined;
      entityType?: "sequences" | undefined;
    } | undefined) => {
      schema: string;
      incrementBy: string | null;
      minValue: string | null;
      maxValue: string | null;
      startWith: string | null;
      cacheSize: number | null;
      cycle: boolean | null;
      name: string;
      entityType: "sequences";
    }[];
    one: (where?: {
      schema?: string | undefined;
      incrementBy?: string | null | undefined;
      minValue?: string | null | undefined;
      maxValue?: string | null | undefined;
      startWith?: string | null | undefined;
      cacheSize?: number | null | undefined;
      cycle?: boolean | null | undefined;
      name?: string | undefined;
      entityType?: "sequences" | undefined;
    } | undefined) => {
      schema: string;
      incrementBy: string | null;
      minValue: string | null;
      maxValue: string | null;
      startWith: string | null;
      cacheSize: number | null;
      cycle: boolean | null;
      name: string;
      entityType: "sequences";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        minValue?: string | ((item: string | null) => string | null) | null | undefined;
        maxValue?: string | ((item: string | null) => string | null) | null | undefined;
        startWith?: string | ((item: string | null) => string | null) | null | undefined;
        cycle?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        incrementBy?: string | ((item: string | null) => string | null) | null | undefined;
        cacheSize?: number | ((item: number | null) => number | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        incrementBy?: string | null | undefined;
        minValue?: string | null | undefined;
        maxValue?: string | null | undefined;
        startWith?: string | null | undefined;
        cacheSize?: number | null | undefined;
        cycle?: boolean | null | undefined;
        name?: string | undefined;
        entityType?: "sequences" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        incrementBy: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cacheSize: number | null;
        cycle: boolean | null;
        name: string;
        entityType: "sequences";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      incrementBy?: string | null | undefined;
      minValue?: string | null | undefined;
      maxValue?: string | null | undefined;
      startWith?: string | null | undefined;
      cacheSize?: number | null | undefined;
      cycle?: boolean | null | undefined;
      name?: string | undefined;
      entityType?: "sequences" | undefined;
    } | undefined) => {
      schema: string;
      incrementBy: string | null;
      minValue: string | null;
      maxValue: string | null;
      startWith: string | null;
      cacheSize: number | null;
      cycle: boolean | null;
      name: string;
      entityType: "sequences";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      incrementBy: string | null;
      minValue: string | null;
      maxValue: string | null;
      startWith: string | null;
      cacheSize: number | null;
      cycle: boolean | null;
      name: string;
      entityType: "sequences";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "sequences";
      schema: string;
      name: string;
      minValue?: {
        from: string | null;
        to: string | null;
      } | undefined;
      maxValue?: {
        from: string | null;
        to: string | null;
      } | undefined;
      startWith?: {
        from: string | null;
        to: string | null;
      } | undefined;
      cycle?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      incrementBy?: {
        from: string | null;
        to: string | null;
      } | undefined;
      cacheSize?: {
        from: number | null;
        to: number | null;
      } | undefined;
      $left: {
        schema: string;
        incrementBy: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cacheSize: number | null;
        cycle: boolean | null;
        name: string;
        entityType: "sequences";
      };
      $right: {
        schema: string;
        incrementBy: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cacheSize: number | null;
        cycle: boolean | null;
        name: string;
        entityType: "sequences";
      };
    }) => boolean;
  };
  roles: {
    push: (input: {
      name: string;
      superuser: boolean | null | undefined;
      createDb: boolean | null | undefined;
      createRole: boolean | null | undefined;
      inherit: boolean | null | undefined;
      canLogin: boolean | null | undefined;
      replication: boolean | null | undefined;
      bypassRls: boolean | null | undefined;
      connLimit: number | null | undefined;
      password: string | null | undefined;
      validUntil: string | null | undefined;
    }, uniques?: ("name" | "superuser" | "createDb" | "createRole" | "inherit" | "canLogin" | "replication" | "bypassRls" | "connLimit" | "password" | "validUntil")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        superuser: boolean | null;
        createDb: boolean | null;
        createRole: boolean | null;
        inherit: boolean | null;
        canLogin: boolean | null;
        replication: boolean | null;
        bypassRls: boolean | null;
        connLimit: number | null;
        password: string | null;
        validUntil: string | null;
        name: string;
        entityType: "roles";
      };
    };
    list: (where?: {
      superuser?: boolean | null | undefined;
      createDb?: boolean | null | undefined;
      createRole?: boolean | null | undefined;
      inherit?: boolean | null | undefined;
      canLogin?: boolean | null | undefined;
      replication?: boolean | null | undefined;
      bypassRls?: boolean | null | undefined;
      connLimit?: number | null | undefined;
      password?: string | null | undefined;
      validUntil?: string | null | undefined;
      name?: string | undefined;
      entityType?: "roles" | undefined;
    } | undefined) => {
      superuser: boolean | null;
      createDb: boolean | null;
      createRole: boolean | null;
      inherit: boolean | null;
      canLogin: boolean | null;
      replication: boolean | null;
      bypassRls: boolean | null;
      connLimit: number | null;
      password: string | null;
      validUntil: string | null;
      name: string;
      entityType: "roles";
    }[];
    one: (where?: {
      superuser?: boolean | null | undefined;
      createDb?: boolean | null | undefined;
      createRole?: boolean | null | undefined;
      inherit?: boolean | null | undefined;
      canLogin?: boolean | null | undefined;
      replication?: boolean | null | undefined;
      bypassRls?: boolean | null | undefined;
      connLimit?: number | null | undefined;
      password?: string | null | undefined;
      validUntil?: string | null | undefined;
      name?: string | undefined;
      entityType?: "roles" | undefined;
    } | undefined) => {
      superuser: boolean | null;
      createDb: boolean | null;
      createRole: boolean | null;
      inherit: boolean | null;
      canLogin: boolean | null;
      replication: boolean | null;
      bypassRls: boolean | null;
      connLimit: number | null;
      password: string | null;
      validUntil: string | null;
      name: string;
      entityType: "roles";
    } | null;
    update: (config: {
      set: {
        name?: string | ((item: string) => string) | undefined;
        superuser?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        createDb?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        createRole?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        inherit?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        canLogin?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        replication?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        bypassRls?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        connLimit?: number | ((item: number | null) => number | null) | null | undefined;
        password?: string | ((item: string | null) => string | null) | null | undefined;
        validUntil?: string | ((item: string | null) => string | null) | null | undefined;
      };
      where?: {
        superuser?: boolean | null | undefined;
        createDb?: boolean | null | undefined;
        createRole?: boolean | null | undefined;
        inherit?: boolean | null | undefined;
        canLogin?: boolean | null | undefined;
        replication?: boolean | null | undefined;
        bypassRls?: boolean | null | undefined;
        connLimit?: number | null | undefined;
        password?: string | null | undefined;
        validUntil?: string | null | undefined;
        name?: string | undefined;
        entityType?: "roles" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        superuser: boolean | null;
        createDb: boolean | null;
        createRole: boolean | null;
        inherit: boolean | null;
        canLogin: boolean | null;
        replication: boolean | null;
        bypassRls: boolean | null;
        connLimit: number | null;
        password: string | null;
        validUntil: string | null;
        name: string;
        entityType: "roles";
      }[];
    };
    delete: (where?: {
      superuser?: boolean | null | undefined;
      createDb?: boolean | null | undefined;
      createRole?: boolean | null | undefined;
      inherit?: boolean | null | undefined;
      canLogin?: boolean | null | undefined;
      replication?: boolean | null | undefined;
      bypassRls?: boolean | null | undefined;
      connLimit?: number | null | undefined;
      password?: string | null | undefined;
      validUntil?: string | null | undefined;
      name?: string | undefined;
      entityType?: "roles" | undefined;
    } | undefined) => {
      superuser: boolean | null;
      createDb: boolean | null;
      createRole: boolean | null;
      inherit: boolean | null;
      canLogin: boolean | null;
      replication: boolean | null;
      bypassRls: boolean | null;
      connLimit: number | null;
      password: string | null;
      validUntil: string | null;
      name: string;
      entityType: "roles";
    }[];
    validate: (data: unknown) => data is {
      superuser: boolean | null;
      createDb: boolean | null;
      createRole: boolean | null;
      inherit: boolean | null;
      canLogin: boolean | null;
      replication: boolean | null;
      bypassRls: boolean | null;
      connLimit: number | null;
      password: string | null;
      validUntil: string | null;
      name: string;
      entityType: "roles";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "roles";
      name: string;
      superuser?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      createDb?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      createRole?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      inherit?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      canLogin?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      replication?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      bypassRls?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      connLimit?: {
        from: number | null;
        to: number | null;
      } | undefined;
      password?: {
        from: string | null;
        to: string | null;
      } | undefined;
      validUntil?: {
        from: string | null;
        to: string | null;
      } | undefined;
      $left: {
        superuser: boolean | null;
        createDb: boolean | null;
        createRole: boolean | null;
        inherit: boolean | null;
        canLogin: boolean | null;
        replication: boolean | null;
        bypassRls: boolean | null;
        connLimit: number | null;
        password: string | null;
        validUntil: string | null;
        name: string;
        entityType: "roles";
      };
      $right: {
        superuser: boolean | null;
        createDb: boolean | null;
        createRole: boolean | null;
        inherit: boolean | null;
        canLogin: boolean | null;
        replication: boolean | null;
        bypassRls: boolean | null;
        connLimit: number | null;
        password: string | null;
        validUntil: string | null;
        name: string;
        entityType: "roles";
      };
    }) => boolean;
  };
  privileges: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      grantor: string;
      grantee: string;
      isGrantable: boolean;
    }, uniques?: ("schema" | "table" | "name" | "type" | "grantor" | "grantee" | "isGrantable")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        grantor: string;
        grantee: string;
        schema: string;
        table: string;
        type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        isGrantable: boolean;
        name: string;
        entityType: "privileges";
      };
    };
    list: (where?: {
      grantor?: string | undefined;
      grantee?: string | undefined;
      schema?: string | undefined;
      table?: string | undefined;
      type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | undefined;
      isGrantable?: boolean | undefined;
      name?: string | undefined;
      entityType?: "privileges" | undefined;
    } | undefined) => {
      grantor: string;
      grantee: string;
      schema: string;
      table: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      isGrantable: boolean;
      name: string;
      entityType: "privileges";
    }[];
    one: (where?: {
      grantor?: string | undefined;
      grantee?: string | undefined;
      schema?: string | undefined;
      table?: string | undefined;
      type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | undefined;
      isGrantable?: boolean | undefined;
      name?: string | undefined;
      entityType?: "privileges" | undefined;
    } | undefined) => {
      grantor: string;
      grantee: string;
      schema: string;
      table: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      isGrantable: boolean;
      name: string;
      entityType: "privileges";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | ((item: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER") => "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER") | undefined;
        grantor?: string | ((item: string) => string) | undefined;
        grantee?: string | ((item: string) => string) | undefined;
        isGrantable?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        grantor?: string | undefined;
        grantee?: string | undefined;
        schema?: string | undefined;
        table?: string | undefined;
        type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | undefined;
        isGrantable?: boolean | undefined;
        name?: string | undefined;
        entityType?: "privileges" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        grantor: string;
        grantee: string;
        schema: string;
        table: string;
        type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        isGrantable: boolean;
        name: string;
        entityType: "privileges";
      }[];
    };
    delete: (where?: {
      grantor?: string | undefined;
      grantee?: string | undefined;
      schema?: string | undefined;
      table?: string | undefined;
      type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | undefined;
      isGrantable?: boolean | undefined;
      name?: string | undefined;
      entityType?: "privileges" | undefined;
    } | undefined) => {
      grantor: string;
      grantee: string;
      schema: string;
      table: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      isGrantable: boolean;
      name: string;
      entityType: "privileges";
    }[];
    validate: (data: unknown) => data is {
      grantor: string;
      grantee: string;
      schema: string;
      table: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      isGrantable: boolean;
      name: string;
      entityType: "privileges";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "privileges";
      schema: string;
      table: string;
      name: string;
      type?: {
        from: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        to: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      } | undefined;
      grantor?: {
        from: string;
        to: string;
      } | undefined;
      grantee?: {
        from: string;
        to: string;
      } | undefined;
      isGrantable?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        grantor: string;
        grantee: string;
        schema: string;
        table: string;
        type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        isGrantable: boolean;
        name: string;
        entityType: "privileges";
      };
      $right: {
        grantor: string;
        grantee: string;
        schema: string;
        table: string;
        type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        isGrantable: boolean;
        name: string;
        entityType: "privileges";
      };
    }) => boolean;
  };
  policies: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      roles: string[];
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      using: string | null | undefined;
      withCheck: string | null | undefined;
    }, uniques?: ("schema" | "table" | "name" | "as" | "roles" | "for" | "using" | "withCheck")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        as: "PERMISSIVE" | "RESTRICTIVE";
        for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        roles: string[];
        using: string | null;
        withCheck: string | null;
        name: string;
        entityType: "policies";
      };
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      as?: "PERMISSIVE" | "RESTRICTIVE" | undefined;
      for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | undefined;
      roles?: string[] | {
        CONTAINS: string;
      } | undefined;
      using?: string | null | undefined;
      withCheck?: string | null | undefined;
      name?: string | undefined;
      entityType?: "policies" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      roles: string[];
      using: string | null;
      withCheck: string | null;
      name: string;
      entityType: "policies";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      as?: "PERMISSIVE" | "RESTRICTIVE" | undefined;
      for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | undefined;
      roles?: string[] | {
        CONTAINS: string;
      } | undefined;
      using?: string | null | undefined;
      withCheck?: string | null | undefined;
      name?: string | undefined;
      entityType?: "policies" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      roles: string[];
      using: string | null;
      withCheck: string | null;
      name: string;
      entityType: "policies";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        as?: "PERMISSIVE" | "RESTRICTIVE" | ((item: "PERMISSIVE" | "RESTRICTIVE") => "PERMISSIVE" | "RESTRICTIVE") | undefined;
        roles?: string[] | ((item: string) => string) | undefined;
        for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | ((item: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE") => "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE") | undefined;
        using?: string | ((item: string | null) => string | null) | null | undefined;
        withCheck?: string | ((item: string | null) => string | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        as?: "PERMISSIVE" | "RESTRICTIVE" | undefined;
        for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | undefined;
        roles?: string[] | {
          CONTAINS: string;
        } | undefined;
        using?: string | null | undefined;
        withCheck?: string | null | undefined;
        name?: string | undefined;
        entityType?: "policies" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        as: "PERMISSIVE" | "RESTRICTIVE";
        for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        roles: string[];
        using: string | null;
        withCheck: string | null;
        name: string;
        entityType: "policies";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      as?: "PERMISSIVE" | "RESTRICTIVE" | undefined;
      for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | undefined;
      roles?: string[] | {
        CONTAINS: string;
      } | undefined;
      using?: string | null | undefined;
      withCheck?: string | null | undefined;
      name?: string | undefined;
      entityType?: "policies" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      roles: string[];
      using: string | null;
      withCheck: string | null;
      name: string;
      entityType: "policies";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      roles: string[];
      using: string | null;
      withCheck: string | null;
      name: string;
      entityType: "policies";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "policies";
      schema: string;
      table: string;
      name: string;
      as?: {
        from: "PERMISSIVE" | "RESTRICTIVE";
        to: "PERMISSIVE" | "RESTRICTIVE";
      } | undefined;
      roles?: {
        from: string[];
        to: string[];
      } | undefined;
      for?: {
        from: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        to: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      } | undefined;
      using?: {
        from: string | null;
        to: string | null;
      } | undefined;
      withCheck?: {
        from: string | null;
        to: string | null;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        as: "PERMISSIVE" | "RESTRICTIVE";
        for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        roles: string[];
        using: string | null;
        withCheck: string | null;
        name: string;
        entityType: "policies";
      };
      $right: {
        schema: string;
        table: string;
        as: "PERMISSIVE" | "RESTRICTIVE";
        for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        roles: string[];
        using: string | null;
        withCheck: string | null;
        name: string;
        entityType: "policies";
      };
    }) => boolean;
  };
  views: {
    push: (input: {
      schema: string;
      name: string;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null | undefined;
      using: string | null | undefined;
      definition: string | null | undefined;
      withNoData: boolean | null | undefined;
      tablespace: string | null | undefined;
      materialized: boolean;
    }, uniques?: ("schema" | "name" | "with" | "using" | "definition" | "withNoData" | "tablespace" | "materialized")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        definition: string | null;
        with: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        withNoData: boolean | null;
        using: string | null;
        tablespace: string | null;
        materialized: boolean;
        name: string;
        entityType: "views";
      };
    };
    list: (where?: {
      schema?: string | undefined;
      definition?: string | null | undefined;
      with?: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null | undefined;
      withNoData?: boolean | null | undefined;
      using?: string | null | undefined;
      tablespace?: string | null | undefined;
      materialized?: boolean | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | undefined) => {
      schema: string;
      definition: string | null;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null;
      withNoData: boolean | null;
      using: string | null;
      tablespace: string | null;
      materialized: boolean;
      name: string;
      entityType: "views";
    }[];
    one: (where?: {
      schema?: string | undefined;
      definition?: string | null | undefined;
      with?: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null | undefined;
      withNoData?: boolean | null | undefined;
      using?: string | null | undefined;
      tablespace?: string | null | undefined;
      materialized?: boolean | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | undefined) => {
      schema: string;
      definition: string | null;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null;
      withNoData: boolean | null;
      using: string | null;
      tablespace: string | null;
      materialized: boolean;
      name: string;
      entityType: "views";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        with?: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | ((item: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null) => {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null) | null | undefined;
        using?: string | ((item: string | null) => string | null) | null | undefined;
        definition?: string | ((item: string | null) => string | null) | null | undefined;
        withNoData?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        tablespace?: string | ((item: string | null) => string | null) | null | undefined;
        materialized?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        definition?: string | null | undefined;
        with?: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null | undefined;
        withNoData?: boolean | null | undefined;
        using?: string | null | undefined;
        tablespace?: string | null | undefined;
        materialized?: boolean | undefined;
        name?: string | undefined;
        entityType?: "views" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        definition: string | null;
        with: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        withNoData: boolean | null;
        using: string | null;
        tablespace: string | null;
        materialized: boolean;
        name: string;
        entityType: "views";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      definition?: string | null | undefined;
      with?: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null | undefined;
      withNoData?: boolean | null | undefined;
      using?: string | null | undefined;
      tablespace?: string | null | undefined;
      materialized?: boolean | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | undefined) => {
      schema: string;
      definition: string | null;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null;
      withNoData: boolean | null;
      using: string | null;
      tablespace: string | null;
      materialized: boolean;
      name: string;
      entityType: "views";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      definition: string | null;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null;
      withNoData: boolean | null;
      using: string | null;
      tablespace: string | null;
      materialized: boolean;
      name: string;
      entityType: "views";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "views";
      schema: string;
      name: string;
      with?: {
        from: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        to: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
      } | undefined;
      using?: {
        from: string | null;
        to: string | null;
      } | undefined;
      definition?: {
        from: string | null;
        to: string | null;
      } | undefined;
      withNoData?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      tablespace?: {
        from: string | null;
        to: string | null;
      } | undefined;
      materialized?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        definition: string | null;
        with: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        withNoData: boolean | null;
        using: string | null;
        tablespace: string | null;
        materialized: boolean;
        name: string;
        entityType: "views";
      };
      $right: {
        schema: string;
        definition: string | null;
        with: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        withNoData: boolean | null;
        using: string | null;
        tablespace: string | null;
        materialized: boolean;
        name: string;
        entityType: "views";
      };
    }) => boolean;
  };
};
type PostgresDDL = ReturnType<typeof createDDL>;
type PostgresEntities = PostgresDDL['_']['types'];
type PostgresEntity = PostgresEntities[keyof PostgresEntities];
//#endregion
//#region src/dialects/postgres/snapshot.d.ts
declare const snapshotValidator: {
  shape: {
    version: "8";
    dialect: "postgres";
    id: string;
    prevIds: string[];
    ddl: PostgresEntity[];
    renames: string[];
  };
  parse: (obj: unknown) => {
    success: boolean;
    data: {
      version: "8";
      dialect: "postgres";
      id: string;
      prevIds: string[];
      ddl: PostgresEntity[];
      renames: string[];
    } | null;
    errors?: string[] | undefined;
  };
  strict: (obj: unknown) => {
    version: "8";
    dialect: "postgres";
    id: string;
    prevIds: string[];
    ddl: PostgresEntity[];
    renames: string[];
  };
};
type PostgresSnapshot = typeof snapshotValidator.shape;
//#endregion
//#region src/ext/api-postgres.d.ts
declare const generateDrizzleJson: (imports: Record<string, unknown>, prevId?: string, schemaFilters?: string[]) => Promise<PostgresSnapshot>;
declare const generateMigration: (prev: PostgresSnapshot, cur: PostgresSnapshot) => Promise<string[]>;
declare const pushSchema: (imports: Record<string, unknown>, drizzleInstance: PgAsyncDatabase<any>, entitiesConfig?: EntitiesFilterConfig, migrationsConfig?: {
  table?: string;
  schema?: string;
}) => Promise<{
  sqlStatements: string[];
  hints: {
    hint: string;
    statement?: string;
  }[];
  apply: () => Promise<void>;
}>;
declare const startStudioServer: (imports: Record<string, unknown>, credentials: PostgresCredentials | {
  driver: "pglite";
  client: PGlite;
}, options?: {
  host?: string;
  port?: number;
  key?: string;
  cert?: string;
}) => Promise<void>;
declare const up: (it: Record<string, any>) => {
  snapshot: PostgresSnapshot;
  hints: string[];
};
//#endregion
export { generateDrizzleJson, generateMigration, pushSchema, startStudioServer, up };