import { c as ZodObject, d as ZodTypeAny, l as ZodOptional, n as ZodArray, p as ZodUnion, r as ZodBoolean, s as ZodNumber, t as TypeOf, u as ZodString } from "./types-DQPabKbg.js";

//#region src/cli/validations/mysql.d.ts
declare const mysqlCredentials: ZodUnion<[ZodObject<{
  host: ZodString;
  port: ZodOptional<ZodNumber>;
  user: ZodOptional<ZodString>;
  password: ZodOptional<ZodString>;
  database: ZodString;
  ssl: ZodOptional<ZodUnion<[ZodString, ZodObject<{
    pfx: ZodOptional<ZodString>;
    key: ZodOptional<ZodString>;
    passphrase: ZodOptional<ZodString>;
    cert: ZodOptional<ZodString>;
    ca: ZodOptional<ZodUnion<[ZodString, ZodArray<ZodString, "many">]>>;
    crl: ZodOptional<ZodUnion<[ZodString, ZodArray<ZodString, "many">]>>;
    ciphers: ZodOptional<ZodString>;
    rejectUnauthorized: ZodOptional<ZodBoolean>;
  }, "strip", ZodTypeAny, {
    pfx?: string | undefined;
    key?: string | undefined;
    passphrase?: string | undefined;
    cert?: string | undefined;
    ca?: string | string[] | undefined;
    crl?: string | string[] | undefined;
    ciphers?: string | undefined;
    rejectUnauthorized?: boolean | undefined;
  }, {
    pfx?: string | undefined;
    key?: string | undefined;
    passphrase?: string | undefined;
    cert?: string | undefined;
    ca?: string | string[] | undefined;
    crl?: string | string[] | undefined;
    ciphers?: string | undefined;
    rejectUnauthorized?: boolean | undefined;
  }>]>>;
}, "strip", ZodTypeAny, {
  host: string;
  database: string;
  password?: string | undefined;
  port?: number | undefined;
  user?: string | undefined;
  ssl?: string | {
    pfx?: string | undefined;
    key?: string | undefined;
    passphrase?: string | undefined;
    cert?: string | undefined;
    ca?: string | string[] | undefined;
    crl?: string | string[] | undefined;
    ciphers?: string | undefined;
    rejectUnauthorized?: boolean | undefined;
  } | undefined;
}, {
  host: string;
  database: string;
  password?: string | undefined;
  port?: number | undefined;
  user?: string | undefined;
  ssl?: string | {
    pfx?: string | undefined;
    key?: string | undefined;
    passphrase?: string | undefined;
    cert?: string | undefined;
    ca?: string | string[] | undefined;
    crl?: string | string[] | undefined;
    ciphers?: string | undefined;
    rejectUnauthorized?: boolean | undefined;
  } | undefined;
}>, ZodObject<{
  url: ZodString;
}, "strip", ZodTypeAny, {
  url: string;
}, {
  url: string;
}>]>;
type MysqlCredentials = TypeOf<typeof mysqlCredentials>;
//#endregion
//#region src/ext/api-mysql.d.ts
declare const startStudioServer: (imports: Record<string, unknown>, credentials: MysqlCredentials, options?: {
  host?: string;
  port?: number;
  key?: string;
  cert?: string;
}) => Promise<void>;
//#endregion
export { startStudioServer };